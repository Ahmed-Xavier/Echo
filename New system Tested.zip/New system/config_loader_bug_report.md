# Bug report: `ConfigLoader` reports the wrong file as missing

## Summary

When any file referenced via a `!include` directive in `config.yaml` is
missing, `ConfigLoader.read_config_file()` reports the **top-level config
file** as "not found" instead of the actual missing included file. This sent
me on a multi-hour debugging detour chasing a phantom filesystem/path issue
that didn't exist, before finding the real cause was a single stale
`!include` line pointing at a config file for a module (`new_closed_loop`)
that doesn't exist on my machine.

## Root cause

In `read_config_file`:

```python
def read_config_file(self, file_path: str = '') -> Any:
    file = self._check_file_exist(file_path)
    try:
        with open(file, 'r') as f:
            yaml.SafeLoader.add_constructor('!include', self._include_config)
            config = yaml.safe_load(f)
        return config
    except FileNotFoundError:
        self.logger.error(f'Default config file:{file} is not found.')
        exit(ExitCode.FILE_NOT_FOUND)
    except Exception as e:
        self.logger.exception(e)
        exit(ExitCode.GENERAL_ERROR)
```

Two very different operations are wrapped in the same `try` block:

1. `open(file, 'r')` — opens the **top-level** config file.
2. `yaml.safe_load(f)` — parses it, which triggers `_include_config()` for
   every `!include` tag, each of which does its own `open(include_path, 'r')`
   on a **different** file.

If any included file is missing, `_include_config()`'s `open()` raises
`FileNotFoundError` from deep inside `yaml.safe_load()`. That exception
propagates up and is caught by the same `except FileNotFoundError` block —
which then logs `file` (the *top-level* path, the only variable in scope),
even though that file opened successfully and isn't the actual problem.

Net effect: the error message always names the top-level `config.yaml`, no
matter which of its (possibly many) included files is actually missing. In a
config with several `!include` lines, this makes the message actively
misleading rather than just unhelpful.

## Suggested fix

Separate opening the top-level file from parsing/including, so each failure
mode reports the file that's actually missing:

```python
def read_config_file(self, file_path: str = '') -> Any:
    file = self._check_file_exist(file_path)
    try:
        with open(file, 'r') as f:
            content = f.read()
    except FileNotFoundError:
        self.logger.error(f'Default config file:{file} is not found.')
        exit(ExitCode.FILE_NOT_FOUND)

    try:
        yaml.SafeLoader.add_constructor('!include', self._include_config)
        config = yaml.safe_load(content)
        return config
    except FileNotFoundError as e:
        self.logger.error(f'Included config file not found: {e}')
        exit(ExitCode.FILE_NOT_FOUND)
    except Exception as e:
        self.logger.exception(e)
        exit(ExitCode.GENERAL_ERROR)
```

Also worth improving `_include_config` itself to name the missing file
explicitly in its own error, rather than relying on the default
`FileNotFoundError` message:

```python
def _include_config(self, loader, node):
    include_path = os.path.join(self._get_current_directory(), loader.construct_scalar(node))
    if not os.path.exists(include_path):
        raise FileNotFoundError(f"Included config not found: {include_path}")
    with open(include_path, 'r') as f:
        return yaml.safe_load(f)
```

With both changes, a missing included file would produce something like:

```
ERROR - Included config file not found: Included config not found: /home/.../functions/new_closed_loop/config.yaml
```

— which points directly at the real problem instead of the unrelated
top-level file.

## How this was found

For reference, in case it helps verify the fix: the top-level `config.yaml`
had a line (my mistake, ngl. but still worth fixing)

```yaml
new_closed_loop : !include functions/new_closed_loop/config.yaml #
```

referencing a module/folder that doesn't exist on this machine. Manually
confirming `os.path.exists()` and a raw `open()` on the top-level
`config.yaml` both succeeded (proving that file was never the problem) is
what eventually pointed at the `!include` chain instead. Removing that one
line resolved the failure immediately, and the service then started, loaded
MQTT, and connected the TCP bridge without further issue.
