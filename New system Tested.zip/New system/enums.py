from enum import Enum, auto


class ExitCode(Enum):
    SUCCESS = 0
    GENERAL_ERROR = 1
    INVALID_ARGUMENTS = 2
    PERMISSION_DENIED = 13
    FILE_NOT_FOUND = 127


# import json
# data = {"offset": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0], "human_class": 2, "init": 1, "object_human": 1, "thorax_alarm": 0, "pelvis_alarm": 0, "thorax_ext_alarm": 0, "fidgetings_alarm": 0, "leaning_forward_alarm": 0, "dissymetry_alarm": 0, "feet_on_dashboard_alarm": 0, "asana_status": 0, "safe_unsafe": 0, "driving_mode": 0, "sensors_avg": [0, 0, 0, 0, 0, 0, 0, 0]}
#
# dumped = json.dumps(data) + '\n'
#
# print(dumped)
#
# loaded = json.loads(dumped)
#
# print(loaded)