import sys
import signal
import argparse
import importlib.util
import logging.config
import time

from config_loader import ConfigLoader
from network.protocol_factory import ProtocolFactory

RELATIVE_MODULE_PATH_APP = 'functions.{0}.app'


class Message:
    def __init__(self, topic, payload):
        self.payload = payload
        self.topic = topic
        self.payload = self.payload.encode()


# https://stackoverflow.com/questions/50731203/should-i-use-events-semaphores-locks-conditions-or-a-combination-thereof-to
# TODO make sure threads are cleaned correctly
# TODO add command line arguments
# TODO use a common message format with { key, payload }

def clean_exit(_signo, _stack_frame):
    """
    2  =>  SIGINT  => CTRL+C - Interrupt from keyboard
    15 =>  SIGTERM => External Exit request - Termination signal
    """
    global function
    global application_running
    if application_running:
        application_running = False
        if _signo == signal.SIGINT:
            print('\b\b  \b\b\r', end='')
            logger.info('Exit requested by user...')
        elif _signo == signal.SIGTERM:
            logger.warning('Exit requested by system...')
        function.on_exit()
    elif _signo == signal.SIGINT:
        function.on_exit()
        # Emergency exit if process is blocked
        exit()


if __name__ == "__main__":

    application_running = True
    signal.signal(signal.SIGINT, clean_exit)
    signal.signal(signal.SIGTERM, clean_exit)

    # Parse arguments
    parser = argparse.ArgumentParser()
    parser.add_argument('-c', '--config', action='store', nargs='+', default="",
                        help='specifies the config file to be used for functions configuration')
    parser.add_argument('-l', '--list', action='store_true', help='returns the list of configured functions and '
                                                                  'available modules, then exits')
    parser.add_argument('-f', '--function',  help='specific function to be launched')
    parser.add_argument('-m', '--module',  help='specific module to be loaded')
    parser.add_argument('-s', '--service', action='store_true', default=True,
                        help='service mode: print debugging messages in compliance with journalctl logs')
    parser.add_argument('-v', '--loglevel', default='DEBUG', help='Log level (default: DEBUG)')

    args = parser.parse_args()

    module_name = args.module or 'transcription'
    function_name = args.function or 'Transcription'
    loglevel = args.loglevel.upper()
    config = args.config or ""
    is_service = args.service
    # print(f'module_name -> {module_name}')
    # print(f'module -> {module_name}')
    # print(f'function -> {function_name}')
    # print(f'loglevel -> {loglevel}')
    # print(f'config_file -> {config}')
    # print(f'is_service -> {is_service}')

    # TODO check if module in the list of modules... else log error
    if not module_name:
        print('ERROR => No module specified', file=sys.stderr)
        exit(-1)

    # Load configuration from config file
    conf_loader = ConfigLoader()
    conf = conf_loader.read_config_file(config)  # pass the config file input here if it's passed as input

    # Config for the Logger
    loggers_conf = conf.get('logging')
    logging.config.dictConfig(loggers_conf)
    logger = logging.getLogger(__name__)

    # Import and instantiate function
    module_full_path = RELATIVE_MODULE_PATH_APP.format(module_name)
    try:
        module = importlib.import_module(module_full_path)
    except ImportError as e:
        logger.error(f"Error importing module '{module_full_path}' : {e}")
        exit()

    # Config for Thermal
    #print('--------> module ------->', module)
    module_conf = conf.get(module_name)
    #print('--------> module ------->', module_conf)

    protocol = ProtocolFactory.create_instance(module_conf.get('protocol'))

    try:
        class_ = getattr(module, function_name)
        function = class_(module_conf, protocol)
        
    except AttributeError as e:
        logger.error(f"Error importing class '{function_name}' : {e}")
        protocol.disconnect()
        exit()

    try:
        while application_running:
            time.sleep(1)
    except KeyboardInterrupt:
        application_running = False
        function.on_exit()
        time.sleep(.2)

        
# python3 main.py -m data_fusion -f DataFusion