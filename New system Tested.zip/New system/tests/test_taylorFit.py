if __name__ == "__main__":


    import importlib
    # import logger, functions
    module_full_path = "../../protocol_factory"
    

    import yaml, os, sys
    

    YAML_PATH = "D:/OneDrive - Faurecia/DisqueD/Projects/Motors/seat-services/config.yaml"

    if 'seat-services' not in sys.path:
    
        current_directory = os.getcwd()
        print(current_directory)
        # current_directory+=f"\seat-services"
        current_directory_slash = current_directory.replace('\\', '/')
        sys.path.append(current_directory_slash)
        sys.path.append(current_directory_slash+"/network")
        sys.path.append(current_directory_slash+"/functions/")

        print(current_directory_slash)



    from protocol_factory import ProtocolFactory
    
    def open_yaml(path: str):
        try:
            with open(path, "r") as file:
                data = yaml.safe_load(file)
                return data
        except Exception as e:
            print("failed to load yaml file...", e)

    # print("hello")
    conf = open_yaml(YAML_PATH)
    # print(conf)
    conf = conf.get('synchro_motor')

    protocol = ProtocolFactory.create_instance(conf.get("protocol"))
    from functions.synchro_motor.app import MotorController

     


    test_control = MotorController(config = conf, protocol = protocol)
    import time

    while True:
        # print("Hello")
        time.sleep(1)
        






            