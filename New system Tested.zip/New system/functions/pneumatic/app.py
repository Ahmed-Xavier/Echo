import os
import sys
import time
import logging
import threading
import json
from enum import Enum
from contextlib import contextmanager
from typing import Dict, Optional
from network.protocol_factory import ProtocolFactory


class Pneumatic_Luxeed:
    """
    Contrôle pneumatique simplifié pour Magic Carpet et Fatigue Sequence.
    """
    
    def __init__(self, config, protocol=None):
        os.chdir(os.path.abspath(os.path.dirname(__file__)))
        self.logger = logging.getLogger(f'{__name__}_{__class__.__name__}')
        self.config = config
        self.protocol = protocol
        
        # MQTT Config
        self.sub_topics = self.config.get('protocol').get('sub_topics')
        self.pub_topics = self.config.get('protocol').get('pub_topics')
        self.protocol.subscribe()
        
        
        # Configuration système
        self.schedule = config.get("protocol_lin").get("schedule")
        self.command_values = self.config.get('command_values')
        self.command_signals = self.config.get('command_signals')
        self.readable_signals = self.config.get('readable_signals')
        self.bladders_max_pressure = self.config.get('bladders_max_pressure')
        self.bladders_min_pressure = self.config.get('bladders_min_pressure')

        self.pressure_values = {bladder: 0 for bladder in self.readable_signals.keys()}
        self._bladder_stop_events = {bladder: threading.Event() for bladder in self.readable_signals.keys()}
        self._bladder_threads = {bladder: None for bladder in self.readable_signals.keys()}
        
        self.max_inflation_time = self.config.get('Actions_cfg').get('max_inflation_time', 10)
        self.max_deflation_time = self.config.get('Actions_cfg').get('max_deflation_time', 10)
        self.pressure_margin = self.config.get('Actions_cfg').get('pressure_margin', 20)

        # Thread-safe state
        self._state_lock = threading.RLock()
        self._is_ready = False
        
        # Protocole LIN
        self.lin_protocol = ProtocolFactory.create_instance(config.get('protocol_lin'))
        self.lin_protocol.connect()
        self.lin_protocol.start_schedule_by_name(self.schedule)
        self.lin_protocol.set_readable_signals(self.readable_signals.values())

   
        # Thread loop
        self.thread_stop_event = threading.Event()
        self.protocol.set_on_receive_callback(self.mqtt_on_message)
        self.thread = threading.Thread(target=self.loop, name="PneumaticThread")
        self.thread.daemon = True
        self.thread.start()
        
        with self._state_lock:
            self._is_ready = True
        
        self.logger.info("Pneumatic system initialized and ready...")

    # ============================================================================
    # PROPRIÉTÉS THREAD-SAFE
    # ============================================================================
    
    @property
    def is_ready(self) -> bool:
        with self._state_lock:
            return self._is_ready
    
    @is_ready.setter
    def is_ready(self, value: bool):
        with self._state_lock:
            self._is_ready = value

    # ============================================================================
    # Functions
    # ============================================================================
        
    def set_valves(self, valve_dict: Dict, state: int):
        """Configure l'état des valves (inflate/deflate)."""
        try:
            for signal in valve_dict.values():
                self.lin_protocol.set_signal(signal, state)
        except Exception as e:
            self.logger.error(f"Erreur configuration valves: {e}")
            raise
    

    def read_pressure(self, bladder):
        try:
            # Accept either a bladder name (str) or a signal index (int).
            if isinstance(bladder, str):
                with self._state_lock:
                    signal = self.readable_signals.get(bladder)
                if signal is None:
                    self.logger.warning(f"Unknown bladder when reading pressure: {bladder}")
                    return 0
                return self.lin_protocol.read_signal(signal)

            # If an integer/signal index is passed, read directly.
            return self.lin_protocol.read_signal(bladder)
        except Exception as e:
            self.logger.error(f"Erreur lecture pression: {e}")
            return 0
    
    # ============================================================================
    # BOUCLE PRINCIPALE
    # ============================================================================
    
    def loop(self):
        """Thread principal pour gérer les événements."""
        self.logger.info("Pneumatic event loop started")
        
        while not self.thread_stop_event.is_set():
            # Avoid reading pressures if LIN is not connected TODO to review as the flag is turned true only on the first connection, and not on reconnection. Maybe we should check the connection status in the LIN protocol instead.
            if not self.lin_protocol._connected:
                time.sleep(0.5)
                continue

            for bladder, signal in self.readable_signals.items():
                try:
                    pressure = self.read_pressure(bladder)
                    # print(f"Pressure for {bladder}: {pressure}")
                    if pressure < 65000: # 65535 is the inflating value, we ignore it to avoid false readings
                        # protect shared state update
                        with self._state_lock:
                            self.pressure_values[bladder] = pressure
                except Exception as e:
                    self.logger.error(f"Erreur lecture pression {bladder}: {e}")
            time.sleep(0.1)
        
        self.logger.info("Pneumatic event loop stopped")


    def handle_inflate(self, bladder: str):
        # Ensure event exists and capture max pressure safely
        print(f"Handling inflate for bladder {bladder}")
        with self._state_lock:
            stop_event = self._bladder_stop_events.get(bladder)
            if stop_event is None:
                stop_event = threading.Event()
                self._bladder_stop_events[bladder] = stop_event
            max_pressure = self.bladders_max_pressure.get(bladder, 0)

        try:
            with self._state_lock:
                current_p = self.pressure_values.get(bladder, 0)
            if current_p >= max_pressure - self.pressure_margin:
                self.logger.info(f"{bladder} already at max pressure ({current_p}).")
                # TODO Only for debug 
                # self.protocol.send(
                #     self.pub_topics.get("target_unreachable_pub"),
                #     bladder,
                #     2,
                #     False
                # )
                self._stop_bladder_action(bladder)
                return

            self.lin_protocol.set_signal(self.command_signals[bladder], self.command_values["Inflate"])

            time_start = time.time()

            while True:
                if self.thread_stop_event.is_set():
                    print("Thread stop event set, breaking inflate loop.")
                    break
                if stop_event.is_set():
                    print(f"Stop event set for {bladder}, breaking inflate loop.")
                    break
                with self._state_lock:
                    current_p = self.pressure_values.get(bladder, 0)
                if current_p >= max_pressure - self.pressure_margin:
                    print(f"{bladder} reached max pressure ({current_p}), breaking inflate loop.")
                    break
                if time.time() - time_start > self.max_inflation_time:
                    print(f"Max inflation time exceeded for {bladder}, breaking inflate loop.")
                    break
                time.sleep(0.05)

        except Exception as e:
            self.logger.error(f"Erreur inflate {bladder}: {e}", exc_info=True)
        finally:
            try:
                self._stop_bladder_action(bladder)
            finally:
                with self._state_lock:
                    self._bladder_threads[bladder] = None


    def handle_deflate(self, bladder: str):
        print(f"Handling deflate for bladder {bladder}")
        with self._state_lock:
            stop_event = self._bladder_stop_events.get(bladder)
            if stop_event is None:
                stop_event = threading.Event()
                self._bladder_stop_events[bladder] = stop_event
            min_pressure = self.bladders_min_pressure.get(bladder, 0)

        try:
            with self._state_lock:
                current_p = self.pressure_values.get(bladder, 0)
            if current_p <= min_pressure + self.pressure_margin:
                self.logger.info(f"{bladder} already at min pressure ({current_p}).")
                self._stop_bladder_action(bladder)
                return

            self.lin_protocol.set_signal(self.command_signals[bladder], self.command_values["Deflate"])

            time_start = time.time()

            while True:
                if self.thread_stop_event.is_set():
                    break
                if stop_event.is_set():
                    break
                if time.time() - time_start > self.max_deflation_time:
                    break
                time.sleep(0.05)

        except Exception as e:
            self.logger.error(f"Erreur deflate {bladder}: {e}", exc_info=True)
        finally:
            try:
                self._stop_bladder_action(bladder)
            finally:
                with self._state_lock:
                    self._bladder_threads[bladder] = None
    
    # ============================================================================
    # GESTION MQTT
    # ============================================================================
    
    def mqtt_on_message(self, message):
        """Traitement des messages MQTT."""
        try:
            topic = message.topic
            payload = message.payload.decode()
            
            self.logger.info(f"Received MQTT: {topic}: {payload}")
            
            # Check readiness
            if topic == self.sub_topics.get("check_is_ready_sub"):
                self.check_is_ready()
                return

            # Stop all
            elif topic == self.sub_topics.get("stop_all"):
                self.stop_all_bladder()
                return

            elif topic == self.sub_topics["reset_sub"]:
                self.reset()
                return

            # Else normal command
            else:
                valve_name = topic.split('/')[-2]
                if payload == str(self.command_values["Stop"]):
                    self.stop_bladder(valve_name)
                    return

                elif payload == str(self.command_values["Inflate"]):
                    self._start_bladder_action(valve_name, "Inflate")
                    return

                elif payload == str(self.command_values["Deflate"]):
                    self._start_bladder_action(valve_name, "Deflate")
                    return


                # TODO check what is this ? 
                if valve_name in self.command_signals:
                    self.lin_protocol.set_signal(self.command_signals[valve_name], self.command_values.get(payload, self.command_values["Stop"]))
        except Exception as e:
            self.logger.error(f"Erreur MQTT: {e}", exc_info=True)
    
    def check_is_ready(self):
        """Publication de l'état de disponibilité."""
        print("Checking readiness...")
        if self.is_ready:
            self.protocol.send(
                self.pub_topics.get("is_ready_pub"),
                self.__class__.__name__,
                2,
                False
            )

    
    def _stop_bladder_action(self, bladder: str):
        """Stop the current movement for one bladder and disable any running action."""
        if bladder not in self.command_signals:
            return

        with self._state_lock:
            stop_event = self._bladder_stop_events.get(bladder)
        if stop_event is not None:
            stop_event.set()

        try:
            self.lin_protocol.set_signal(self.command_signals[bladder], self.command_values["Stop"])
        except Exception as e:
            self.logger.error(f"Erreur stop bladder {bladder}: {e}")

    def stop_bladder(self, bladder: str):
        """Cancel any current inflate/deflate action for a single bladder."""
        print(f"Stopping bladder {bladder}")
        self._stop_bladder_action(bladder)

    def stop_all_bladder(self):
        """Stop all bladder motion immediately."""
        # iterate readable_signals: these represent actual bladders; command_signals
        # may be a different mapping or contain extra control signals. Using
        # readable_signals ensures we stop only real bladder actuators.
        print("Stopping all bladders")
        for bladder in self.readable_signals.keys():
            self.stop_bladder(bladder)

    def _start_bladder_action(self, bladder: str, action: str):
        """Start only one valid action for a bladder, cancelling the previous one if needed."""
        with self._state_lock:
            if bladder not in self.command_signals:
                self.logger.warning(f"Unknown bladder command: {bladder}")
                return
            if action not in self.command_values:
                self.logger.warning(f"No command {action} signal defined for bladder {bladder}")
                return

            stop_event = self._bladder_stop_events.get(bladder)
            if stop_event is None:
                stop_event = threading.Event()
                self._bladder_stop_events[bladder] = stop_event

            previous_thread = self._bladder_threads.get(bladder)

        if previous_thread is not None and previous_thread.is_alive():
            self.logger.info(f"Cancelling previous action for {bladder} before starting {action}")
            stop_event.set()
            previous_thread.join(timeout=0.2)  # Wait up to 1 second for the thread to finish

        # Always clear the stop event before starting the new action, 
        # after ensuring the previous thread has had time to finish
        stop_event.clear()

        # STOP is already handled by payload check in mqtt_on_message, so we don't need to start a thread for it.
        target = self.handle_inflate if action == "Inflate" else self.handle_deflate
        thread = threading.Thread(
            target=target,
            args=(bladder,),
            name=f"{bladder}{action}Thread",
            daemon=True,
        )
        with self._state_lock:
            self._bladder_threads[bladder] = thread
        thread.start()


 #============================================================================
 #SHUTDOWN
 #============================================================================

    def on_exit(self):
        self.logger.info("Arrêt du système pneumatique...")
        self.thread_stop_event.set()
        self.stop_all_bladder()

        try:
            self.set_valves(self.command_signals, self.command_values["Stop"])
        except Exception as e:
            self.logger.error(f"Erreur arrêt des valves: {e}")

        if self.thread and self.thread.is_alive():
            self.thread.join(timeout=3)

        try:
            if self.protocol:
                self.protocol.disconnect()
        except Exception as e:
            self.logger.error(f"Erreur déconnexion MQTT: {e}")

        try:
            if self.lin_protocol:
                self.lin_protocol.disconnect()
        except Exception as e:
            self.logger.error(f"Erreur déconnexion LIN: {e}")

        self.is_ready = False
        self.logger.info("Système pneumatique arrêté")

    def reset(self):
        self.is_ready = False
        self.logger.info("Resetting service Pneumatics to default...")

        try:
            self.thread_stop_event.clear()
            self.stop_all_bladder()
            self.set_valves(self.command_signals, self.command_values["Stop"])
            self.pressure_values = {bladder: 0 for bladder in self.readable_signals.keys()}

            if self.lin_protocol:
                self.lin_protocol.start_sechdule_by_number(self._current_schedule)
                self.lin_protocol.set_readable_signals(self.readable_signals.values())

            for bladder in self._bladder_stop_events:
                self._bladder_stop_events[bladder].clear()

        except Exception as e:
            self.logger.error(f"Erreur reset pneumatique: {e}", exc_info=True)
        finally:
            self.is_ready = True
            self.logger.info("Pneumatic resetted completed.")


# mosquitto_pub.exe -t 127.0.0.1 -t "SM/Seat/Pneumatic/LumbarHigh/Direction" -m 0