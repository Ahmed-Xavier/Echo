# ======================================================
# Closed Loop App / Orchestrator
# ======================================================
# Purpose: mode selection, active-loop lifecycle management
# and wiring to publish_command. Mode tuning belongs in
# `config.yaml` so operators can change behavior without
# editing orchestration code.
# ======================================================
from __future__ import annotations

import json
import queue
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Any, Callable, Dict, Optional

import yaml

from network.protocol_factory import ProtocolFactory
from .closed_loop.closed_loop import BladderEngine, ClosedLoopEngine, EngineWatchdog

# =====================================================
# CONFIGURATION LOADING
#
# This file is the service-level entry point.  All tunable behaviour belongs
# in config.yaml, not in this Python file: sensor mapping and ratio formulas
# live in the engine config, while modes, MQTT topics, and timing are read by
# this orchestrator.
# =====================================================
def load_config(config_path: Optional[Path] = None) -> Dict[str, object]:
    path = config_path or Path(__file__).with_name("config.yaml")
    with path.open("r", encoding="utf-8") as handle:
        return yaml.safe_load(handle) or {}


# Converts YAML values such as true, "true", "yes", or 1 into one boolean.
# It is used only for the `debug` configuration switch.
def _coerce_bool(value: object) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.strip().lower() in {"1", "true", "yes", "on"}
    return bool(value)


CONFIG = load_config()
CONTROL_SETTINGS = CONFIG.get("control", {})
PNEUMATIC_TOPICS = CONFIG.get("pneumatics_commands", {})
PROTOCOL_SUB_TOPICS = CONFIG.get("protocol", {}).get("sub_topics", {})
PROTOCOL_PUB_TOPICS = CONFIG.get("protocol", {}).get("pub_topics", {})
MODE_DEFINITIONS = CONFIG.get("modes", {})
DEBUG_ENABLED = _coerce_bool(CONFIG.get("debug", False))


# =====================================================
# LIVE CONFIGURATION RELOAD
#
# The dictionaries are mutated in place so code that imported a settings
# dictionary keeps seeing the current values after the debug UI saves tuning.
# New engines use the fresh settings; existing engines are updated by the UI.
# =====================================================
def reload_config() -> None:
    fresh_config = load_config()

    CONFIG.clear()
    CONFIG.update(fresh_config)

    CONTROL_SETTINGS.clear()
    CONTROL_SETTINGS.update(CONFIG.get("control", {}))

    PNEUMATIC_TOPICS.clear()
    PNEUMATIC_TOPICS.update(CONFIG.get("pneumatics_commands", {}))

    PROTOCOL_SUB_TOPICS.clear()
    PROTOCOL_SUB_TOPICS.update(CONFIG.get("protocol", {}).get("sub_topics", {}))

    global PROTOCOL_PUB_TOPICS
    PROTOCOL_PUB_TOPICS.clear()
    PROTOCOL_PUB_TOPICS.update(CONFIG.get("protocol", {}).get("pub_topics", {}))

    MODE_DEFINITIONS.clear()
    MODE_DEFINITIONS.update(CONFIG.get("modes", {}))

    global DEBUG_ENABLED
    DEBUG_ENABLED = _coerce_bool(CONFIG.get("debug", False))


# =====================================================
# CLOSED-LOOP SERVICE ORCHESTRATOR
#
# Owns one shared ClosedLoopEngine (sensor math) and one BladderEngine thread
# per active bladder.  This class deliberately does not know how MQTT, TCP,
# or Tkinter work; it receives offsets and sends final commands through
# callbacks supplied by the entry point.
# =====================================================
class ClosedLoopMain:
    # Builds the runtime orchestrator.
    # Input:
    # - config: configuration dictionary injected by main.py loader.
    # - protocol: primary MQTT connection object built and injected by main.py.
    # - publish_command: optional custom callback (used by debug dashboard / tests).
    def __init__(
        self,
        config: Optional[Dict[str, Any]] = None,
        protocol: Optional[Any] = None,
        publish_command: Optional[Callable[[str, str], None]] = None,
    ):
        self.config = config if config is not None else CONFIG
        self.mqtt = protocol
        self._custom_publish_command = publish_command
        self.command_log: queue.Queue = queue.Queue()
        self.aio_data: Dict[str, Any] = {}
        # A zero object_human value means the seat is empty.  Direction
        # commands remain blocked until a non-zero value arrives from AiO.
        self.occupied: Any = 0

        if self.mqtt:
            try:
                self.mqtt.set_on_receive_callback(
                    lambda msg: self._on_mqtt_message(
                        msg.topic,
                        msg.payload.decode("utf-8", errors="ignore")
                        if isinstance(msg.payload, bytes)
                        else str(msg.payload),
                    )
                )

            except Exception:
                pass

        self.active_mode: Optional[str] = None
        self.engine = ClosedLoopEngine(publish_command=self.publish_command, config=self.config)
        self.active_engines: Dict[str, BladderEngine] = {}
        self.watchdog = EngineWatchdog(get_active_engines=lambda: self.active_engines)
        self.watchdog.start()
        self._lock = threading.Lock()
        self._exit_lock = threading.Lock()
        self._exited = False

        # Build secondary AiO / TCP bridge connection
        self.tcp_bridge = TCPBridge(service=self)

        self._debug_process: Optional[subprocess.Popen] = None
        self._stop_status_event = threading.Event()
        self._status_thread: Optional[threading.Thread] = None

        if _coerce_bool(self.config.get("debug", False)):
            try:
                print("[CLOSED_LOOP] Spawning debug dashboard process")
                self._debug_process = subprocess.Popen(
                    [sys.executable, "-m", "functions.closed_loop.debug"]
                )
            except Exception as exc:
                print(f"[CLOSED_LOOP] Failed to spawn debug dashboard process: {exc}")

        # Start periodic status publisher thread (4 Hz)
        self._status_thread = threading.Thread(target=self._publish_status_loop, daemon=True)
        self._status_thread.start()

    # This block is to feed the debug window thro MQTT
    def _publish_status_loop(self) -> None:
        """Periodically publish JSON snapshot of active bladder states over MQTT for UI observers."""
        while not self._stop_status_event.is_set():
            if self.active_mode and self.active_engines:
                try:
                    status_topic = PROTOCOL_PUB_TOPICS.get("status_pub", "Seat/ClosedLoop/Status")
                    payload = json.dumps({
                        "active_mode": self.active_mode,
                        "bladders": self.get_status()
                    })
                    self.publish_command(status_topic, payload)
                except Exception as exc:
                    print(f"[CLOSED_LOOP] Error publishing status snapshot: {exc}")
            time.sleep(0.25)  # 4 Hz update rate

    def reload_and_update_engines(self) -> None:
        """Reload config.yaml and reconcile active engines with positive targets."""
        print("[CLOSED_LOOP] Reloading configuration from disk...")
        reload_config()

        if not self.active_mode:
            return

        mode_cfg = MODE_DEFINITIONS.get(self.active_mode, {})
        targets = mode_cfg.get("targets", {})
        active_targets = {
            name: target
            for name, target in targets.items()
            if isinstance(target, (int, float)) and target > 0
        }

        engines_to_stop = []
        names_to_start = []
        with self._lock:
            for name, engine in list(self.active_engines.items()):
                new_target = active_targets.get(name)
                if new_target is None:
                    engines_to_stop.append(engine)
                    del self.active_engines[name]
                    continue

                control = CONTROL_SETTINGS
                try:
                    engine.update_tunables(
                        target_ratio=new_target,
                        margin=control.get("default_margin", 0.025),
                        debounce_under=control.get("default_debounce_under", 5),
                        debounce_over=control.get("default_debounce_over", 5),
                        debounce_good=control.get("default_debounce_good", 10),
                    )
                    print(f"[CLOSED_LOOP] Updated tunables for engine {name}: target={new_target:.3f}")
                except Exception as exc:
                    print(f"[CLOSED_LOOP] Failed to update tunables for engine {name}: {exc}")

            names_to_start = [
                name for name in active_targets if name not in self.active_engines
            ]

        for engine in engines_to_stop:
            engine.stop()

        for name in names_to_start:
            engine = self._build_engine(name)
            engine.start()
            with self._lock:
                self.active_engines[name] = engine

    # this block tells the system how to publish an MQTT command, it will be called later.
    def publish_command(self, topic: str, payload: str) -> None:
        if self._custom_publish_command:
            self._custom_publish_command(topic, payload)
            return

        self.command_log.put(f"[MQTT] {topic} -> {payload}")
        if self.mqtt:
            try:
                self.mqtt.send(topic, payload, 2, False)
            except Exception as exc:
                self.command_log.put(f"[MQTT ERROR] {exc}")
                print(f"[MQTT ERROR] {exc}")

    #This function blocks MQTT messages from getting published if seat is empty
    def publish_bladder_command(self, topic: str, payload: str) -> bool:
        """Publish a bladder command, blocking movement while the seat is empty.

        Stop commands deliberately remain allowed so the pneumatic service can
        always halt a movement that started before occupancy changed.
        """
        direction_topics = {
            command.get("topic_dir")
            for command in PNEUMATIC_TOPICS.values()
            if isinstance(command, dict) and command.get("topic_dir")
        }
        if topic in direction_topics and self.occupied == 0:
            message = f"[MQTT BLOCKED] empty seat: {topic} -> {payload}"
            self.command_log.put(message)
            print(message)
            return False
    # See! it's called here and used to actually publish and MQTT command.
        self.publish_command(topic, payload)
        return True

    # =================================================
    # SENSOR FRAME ENTRY POINT
    #
    # TCPBridge calls this for every validated AiO frame.  Keep conversion and
    # ratio math in ClosedLoopEngine so every mode uses the same live values.
    # ================================================= 

    def update_aio_data(self, data: Dict[str, Any]) -> None:
        """Store an AiO frame and forward valid offsets to the ratio engine."""
        self.aio_data = data
        previous_occupied = self.occupied
        self.occupied = self.aio_data.get("object_human", 0)   
        self.occupied = 1  #uncomment this line to force occupied for testing purposes

        #these lines added for safe stop when seat becomes empty 
        #after it was occupied, to avoid any movement when seat is empty
        #emergency_stop function exists in closed_loop.py
        #=======================================================
        if previous_occupied != 0 and self.occupied == 0:
            with self._lock:
                engine_to_stop = list(self.active_engines.values())
            for engine in engine_to_stop:
                engine.emergency_stop() 

        offsets = self.aio_data.get("offset", [])
        #=======================================================                                                                   

        if not isinstance(offsets, list) or len(offsets) < 17:
            length = len(offsets) if isinstance(offsets, list) else 0
            print(f"[TCPBridge] ignoring offset frame of length {length}")
            return

        self.engine.update_offsets(offsets)

    # =================================================
    # DEBUG STATUS SNAPSHOT
    #
    # Returns one UI-safe view of the running threads.  The dashboard uses
    # this rather than reading configuration files or calculating ratios.
    # =================================================
    def get_status(self) -> Dict[str, Dict[str, object]]:
        """Return current ratio, target, and last decision for each active bladder."""
        status: Dict[str, Dict[str, object]] = {}
        with self._lock:
            for name, engine in self.active_engines.items():
                status[name] = {
                    "current": self.engine.get_ratio(name),
                    "target": engine.target_ratio,
                    "state": engine.state,
                    "faulted": engine.faulted,
                    "fault_reason": engine.fault_reason,
                }
        return status

    # =================================================
    # PER-BLADDER ENGINE FACTORY
    #
    # This is where each config section meets: mode targets choose what to
    # control, control settings tune timing/debounce, and pneumatics_commands
    # determine the outgoing MQTT topics.  Add a new bladder in config first;
    # avoid hard-coding bladder-specific values here.
    # =================================================
    def _build_engine(self, bladder_name: str) -> BladderEngine:
        mode_config = MODE_DEFINITIONS.get(self.active_mode or "", {})
        targets = mode_config.get("targets", {})
        control = CONTROL_SETTINGS
        target_ratio = targets.get(bladder_name, 0.0)
        return BladderEngine(
            name=bladder_name,
            get_ratio=lambda: self.engine.get_ratio(bladder_name),
            publish_command=self.publish_bladder_command,
            get_occupied=lambda: self.occupied,
            target_ratio=target_ratio,
            margin=control.get("default_margin", 0.025), #the values are just fallbacks, the real values are in config.yaml
            debounce_under=control.get("default_debounce_under", 5), #the values are just fallbacks, the real values are in config.yaml
            debounce_over=control.get("default_debounce_over", 5), #the values are just fallbacks, the real values are in config.yaml
            debounce_good=control.get("default_debounce_good", 10), #the values are just fallbacks, the real values are in config.yaml
            loop_interval_s=control.get("loop_interval_s", 0.1), #the values are just fallbacks, the real values are in config.yaml
            direction_topic=PNEUMATIC_TOPICS.get(bladder_name, {}).get("topic_dir", f"{bladder_name}/Direction"),
            stop_topic=PNEUMATIC_TOPICS.get(bladder_name, {}).get("topic_stop", f"{bladder_name}/Direction"),
            one_shot=mode_config.get("one_shot", False),
        )

    # Stops and removes every currently active bladder engine.  This is used
    # before a mode change and at shutdown; each engine publishes one Stop.
    def _stop_previous_mode(self) -> None:
        with self._lock:
            engines_to_stop = list(self.active_engines.values())
            self.active_engines.clear()

        for engine in engines_to_stop:
            engine.stop()

    # =================================================
    # SERVICE SHUTDOWN
    #
    # Always stop bladder threads before stopping the watchdog.  This method
    # is safe to call from window-close, signal, and process-exit paths.
    # =================================================
    def shutdown_all(self) -> None:
        """Stop active engines and stop the watchdog thread."""
        self._stop_previous_mode()
        self.watchdog.stop()

    def on_exit(self) -> None:
        """Shutdown service, stop threads, and disconnect protocols cleanly."""
        with self._exit_lock:
            if self._exited:
                return
            self._exited = True

        print("[CLOSED_LOOP] Shutting down ClosedLoopService...")
        self._stop_status_event.set()

        # Step 1: Stop all running engines (each publishes 'Stop' to its stop_topic)
        self.shutdown_all()

        # Step 2: Publish final stopped status snapshot and clear mode
        try:
            status_topic = PROTOCOL_PUB_TOPICS.get("status_pub", "Seat/ClosedLoop/Status")
            mode_topic = PROTOCOL_SUB_TOPICS.get("mode_switch_sub", "SM/ClosedLoop/ActiveMode")
            payload = json.dumps({"active_mode": "none", "bladders": {}})
            self.publish_command(status_topic, payload)
            self.publish_command(mode_topic, "0")
        except Exception as exc:
            print(f"[CLOSED_LOOP] Error publishing shutdown status: {exc}")

        # Step 3: Pause briefly (0.3s) to flush queued MQTT packets (QoS 2) to broker socket
        time.sleep(0.3)

        # Step 4: Terminate debug subprocess if active
        if self._debug_process and self._debug_process.poll() is None:
            try:
                print("[CLOSED_LOOP] Terminating debug window process...")
                self._debug_process.terminate()
                self._debug_process.wait(timeout=2.0)
            except Exception:
                try:
                    self._debug_process.kill()
                except Exception:
                    pass

        # Step 5: Tear down TCP bridge and disconnect MQTT
        if hasattr(self, "tcp_bridge") and self.tcp_bridge:
            try:
                self.tcp_bridge.stop()
            except Exception:
                pass
        if self.mqtt:
            try:
                self.mqtt.disconnect()
            except Exception:
                pass
        print("[CLOSED_LOOP] ClosedLoopService shutdown complete.")

    # =================================================
    # MODE LIFECYCLE
    #
    # A mode name comes from MQTT or the debug window.  A positive target
    # starts a bladder engine; a target of zero marks that bladder inactive.
    # =================================================
    def start_mode(self, mode_name: str) -> None:
        if mode_name.lower() in {"stop", "none", "off", ""}:
            self._stop_previous_mode()
            with self._lock:
                self.active_mode = None
            return

        if mode_name not in MODE_DEFINITIONS:
            print(f"[CLOSED_LOOP] Unknown mode: {mode_name}")
            return

        self._stop_previous_mode()

        with self._lock:
            self.active_mode = mode_name
            mode_config = MODE_DEFINITIONS[mode_name]
            targets = mode_config.get("targets", {})
            active_targets = {
                name: target
                for name, target in targets.items()
                if isinstance(target, (int, float)) and target > 0
            }

            for bladder_name in active_targets:
                engine = self._build_engine(bladder_name)
                engine.start()
                self.active_engines[bladder_name] = engine

    # =================================================
    # INBOUND MQTT ROUTER
    #
    # Keep message-topic names in config.yaml.  At this stage the service
    # handles readiness requests, mode changes, and config reload triggers.
    # =================================================
    def _on_mqtt_message(self, topic: str, payload: str) -> None:
        payload_text = payload.strip()

        if topic == PROTOCOL_SUB_TOPICS.get("check_is_ready_sub", "SM/Seat/Check/IsReady"):
            is_ready_topic = PROTOCOL_PUB_TOPICS.get("is_ready_pub", "Seat/SM/IsReady")
            self.publish_command(is_ready_topic, "true")
            return

        if topic == PROTOCOL_SUB_TOPICS.get("mode_switch_sub", "SM/ClosedLoop/ActiveMode"):
            self.start_mode(payload_text)
            return

        if topic == PROTOCOL_SUB_TOPICS.get("reload_config_sub", "SM/ClosedLoop/ReloadConfig"):
            self.reload_and_update_engines()
            return

    def set_mode_from_mqtt(self, topic: str, payload: str) -> None:
        self._on_mqtt_message(topic, payload)


# =====================================================
# AIO TCP INPUT BRIDGE
#
# Owns the transport connection only.  Every complete JSON line containing an
# `offset` array is passed to ClosedLoopMain, which then calculates ratios.
# This keeps networking separate from the control algorithm.
# =====================================================
class TCPBridge:
    """Feed newline-delimited AiO TCP frames into ``ClosedLoopMain``."""

    def __init__(self, service: Any, host: Optional[str] = None, port: Optional[int] = None):
        self.service = service
        config = load_config()
        aio_cfg = dict(config.get("aio_protocol", {}))
        if host is not None:
            aio_cfg["host"] = host
        if port is not None:
            aio_cfg["port"] = port

        self._buffer = ""
        self._aio_protocol = None

        if not aio_cfg:
            raise ValueError(
                "Missing 'aio_protocol' in "
                f"{Path(__file__).with_name('config.yaml')}"
            )

        aio_cfg.setdefault("type", "tcp_client")
        print(
            "[TCPBridge] creating AiO TCP protocol for "
            f"{aio_cfg.get('host')}:{aio_cfg.get('port')}"
        )
        try:
            self._aio_protocol = ProtocolFactory.create_instance(aio_cfg)
            self._aio_protocol.set_on_receive_callback(self._on_aio_receive)
        except Exception as exc:
            print(f"[TCPBridge] failed to create AiO TCP protocol: {exc}")
            self._aio_protocol = None

    def start(self) -> None:
        # ProtocolFactory-created TCPClient already connects on construction.
        return

    def stop(self) -> None:
        if self._aio_protocol:
            try:
                self._aio_protocol.disconnect()
            except Exception:
                pass

    def _on_aio_receive(self, raw: str) -> None:
        if raw is None:
            return

        self._buffer += raw
        complete_frames = self._buffer.split("\n")
        self._buffer = complete_frames.pop()

        for raw_frame in complete_frames:
            line = raw_frame.strip()
            if not line:
                continue
            try:
                frame = json.loads(line)
            except json.JSONDecodeError as exc:
                print(f"[TCPBridge] JSON parse failed: {exc} -- frame={line[:200]!r}")
                continue

            self.service.update_aio_data(frame)


# =====================================================
# STANDALONE DIRECT-RUN ENTRY POINT
#
# Enables manual package testing via `python -m functions.closed_loop.app`.
# Production startup uses main.py, which builds protocol/config and calls on_exit().
# =====================================================
def main() -> None:
    reload_config()

    import time
    from network.mqtt import MQTT

    mqtt_cfg = CONFIG.get("protocol", {})
    mqtt_conf = {**mqtt_cfg, "sub_topics": mqtt_cfg.get("sub_topics", {})}
    mqtt_conf.setdefault("function", "ClosedLoopService")
    mqtt_client = MQTT(mqtt_conf)

    service = ClosedLoopMain(config=CONFIG, protocol=mqtt_client)

    print("[CLOSED_LOOP] Service active in standalone mode. Listening for MQTT commands... Press Ctrl+C to stop.")
    try:
        while True:
            time.sleep(1)
    except (KeyboardInterrupt, SystemExit):
        service.on_exit()


if __name__ == "__main__":
    main()
