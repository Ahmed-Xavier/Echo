# ======================================================
# Closed Loop Engine
# ======================================================
# Purpose: engine code for per-bladder control loops, ratio
# calculation, debounce and decision logic. Keep tunables
# in `config.yaml` and avoid hardcoding literals here.
# ======================================================
from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Dict, List, Optional, Union

import yaml


# =====================================================
# ENGINE CONFIGURATION
#
# The engine reads the same closed-loop config as the app.  Sensor mappings,
# sensor groups, ratio formulas, and control timing are intentionally data,
# so seat tuning does not require editing control logic.
# =====================================================
def load_config(config_path: Optional[Path] = None) -> Dict[str, object]:
    path = config_path or Path(__file__).resolve().parents[1] / "config.yaml"
    with path.open("r", encoding="utf-8") as handle:
        return yaml.safe_load(handle) or {}


CONFIG = load_config()
SENSOR_MAPPING = CONFIG.get("sensor_to_index_mapping", {})
CONFIG_SEAT = CONFIG.get("config_seat", {})
RATIO_FORMULAS = CONFIG.get("ratio_formulas", {})
SENSOR_GROUPS = CONFIG_SEAT.get("sensor_groups", {})
CONTROL_SETTINGS = CONFIG.get("control", {})
MQTT_TOPICS = CONFIG.get("mqtt_topics", {})
MODE_DEFINITIONS = CONFIG.get("modes", {})


# =====================================================
# ONE CONTROL THREAD PER BLADDER
#
# BladderEngine has no TCP/MQTT dependency.  It receives the latest ratio
# through `get_ratio` and emits only Front, Rear, or Stop through
# `publish_command`.  The app wires those callbacks from config.
# =====================================================
@dataclass
class BladderEngine:
    # These are the main tuning knobs for each bladder loop.
    # Keep changes here minimal; prefer adjusting them in config.yaml.
    name: str
    get_ratio: Callable[[], float]
    publish_command: Callable[[str, str], Optional[bool]]
    target_ratio: float = 0.0
    margin: float = 0.0
    debounce_under: int = 0
    debounce_over: int = 0
    debounce_good: int = 0
    loop_interval_s: float = 0.0
    direction_topic: str = ""
    stop_topic: str = ""
    action_under: str = "1"
    action_over: str = "2"
    one_shot: bool = False
    get_occupied: Optional[Callable[[], object]] = None

    _under_count: int = 0
    _over_count: int = 0
    _good_count: int = 0
    _stop_event: threading.Event = field(default_factory=threading.Event)
    _thread: Optional[threading.Thread] = None
    _last_decision: str = "0"
    _last_loop_time: float = field(default_factory=time.time)
    _healthy: bool = True
    _completed_normally: bool = False
    _last_error: Optional[str] = None
    _faulted: bool = False
    _fault_reason: Optional[str] = None

    # =================================================
    # ENGINE CONFIGURATION VALIDATION
    #
    # Reject invalid tunables before starting a background thread.  All values
    # normally come from config.yaml, making configuration mistakes visible at
    # startup rather than during a seat movement.
    # =================================================
    def __post_init__(self) -> None:
        if not self.direction_topic:
            self.direction_topic = f"{self.name}/direction"
        if not self.stop_topic:
            self.stop_topic = f"{self.name}/0"

        if self.target_ratio < 0:
            raise ValueError(f"{self.name}: target_ratio must be >= 0, got {self.target_ratio}")
        if not (0 <= self.margin < 1.0):
            raise ValueError(
                f"{self.name}: margin must be in [0, 1.0), got {self.margin} "
                f"(a margin >= 1.0 makes the 'under' state mathematically unreachable)"
            )
        if self.debounce_under < 1 or self.debounce_over < 1 or self.debounce_good < 1:
            raise ValueError(
                f"{self.name}: debounce_under/over/good must all be >= 1, "
                f"got {self.debounce_under}/{self.debounce_over}/{self.debounce_good}"
            )
        if self.loop_interval_s <= 0:
            raise ValueError(f"{self.name}: loop_interval_s must be > 0, got {self.loop_interval_s}")

        self._last_loop_time = time.time()

    #rese count fonction, just added for fun, I mean to be used by other functions.
    def reset_count(self) -> None:
        self._under_count = 0
        self._over_count = 0
        self._good_count = 0

    # Resets runtime counters for a fresh mode.  It does not alter configured
    # target, margin, topics, or timing values.
    def reset_state(self) -> None:
        self.reset_count()
        self._last_decision = "0"
        self._faulted = False
        self._fault_reason = None

    # Live-updates control tunables in-place on the running engine thread.
    def update_tunables(
        self,
        target_ratio: float,
        margin: float,
        debounce_under: int,
        debounce_over: int,
        debounce_good: int,
    ) -> None:
        if target_ratio < 0:
            raise ValueError(f"{self.name}: target_ratio must be >= 0, got {target_ratio}")
        if not (0 <= margin < 1.0):
            raise ValueError(f"{self.name}: margin must be in [0, 1.0), got {margin}")
        if debounce_under < 1 or debounce_over < 1 or debounce_good < 1:
            raise ValueError(
                f"{self.name}: debounce_under/over/good must all be >= 1, "
                f"got {debounce_under}/{debounce_over}/{debounce_good}"
            )

        self.target_ratio = target_ratio
        self.margin = margin
        self.debounce_under = debounce_under
        self.debounce_over = debounce_over
        self.debounce_good = debounce_good

    @property
    def state(self) -> str:
        return self._last_decision

    @property
    def healthy(self) -> bool:
        return self._healthy
    
    @property
    def completed_normally(self) -> bool:
        return self._completed_normally
    
    @property
    def last_error(self) -> Optional[str]:
        return self._last_error

    @property
    def seconds_since_last_loop(self) -> float:
        return time.time() - self._last_loop_time

    @property
    def faulted(self) -> bool:
        return self._faulted
    
    # FAULT DISPLAY PIPELINE (currently unused — reserved for future fault logic)
    #
    # How to wire a new fault into the debug window:
    #   1. In BladderEngine, set:  self._faulted = True
    #                              self._fault_reason = "your message"
    #   2. The debug panel reads these via get_status() → engine.faulted / fault_reason
    #   3. The UI turns the panel red and prints the message automatically.
    #
    # No changes needed in app.py or debug.py. 
    @property
    def fault_reason(self) -> Optional[str]:
        return self._fault_reason

    # =================================================
    # THREAD LIFECYCLE
    #
    # One daemon thread evaluates one bladder at `loop_interval_s`.  The app
    # starts and stops these threads when a mode changes.
    # =================================================
    def start(self) -> None:
        self._stop_event.clear()
        self.reset_state()
        if self._thread is None or not self._thread.is_alive():
            self._thread = threading.Thread(target=self._run, daemon=True)
            self._thread.start()

    # Stops this bladder's thread and always publishes one final Stop command.
    def stop(self) -> None:
        self._stop_event.set()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=1.0)
            if self._thread.is_alive():
                print(
                    f"[CLOSED_LOOP] WARNING: {self.name}'s thread did not stop within 1.0s -- "
                    f"it may still be running and could still publish a stale command."
                )
        self.publish_command(self.stop_topic, "0")


    # Immediately publihes Stop outside the normal decision cycle and resets debounce count   
    # it can resume normally once seat is occupied  
    def emergency_stop(self) -> None:
        self.publish_command(self.stop_topic, "0")
        self._last_decision = "0"
        self.reset_count()


    # =================================================
    # CLOSED-LOOP DECISION CYCLE
    #
    # Each iteration uses the newest calculated ratio, classifies it against
    # target ± margin, applies debounce, and publishes only on a state change.
    # The broad exception handler keeps one bad frame from killing the loop.
    # =================================================
    def _run(self) -> None:
        while not self._stop_event.is_set():
            try:
                ratio_value = self.get_ratio()
                state = self._get_state(ratio_value)
                decision = self._evaluate(ratio_value)

                print(
                    f"[CLOSED_LOOP] {self.name}"
                    f" ratio={ratio_value:.3f}"
                    f" target={self.target_ratio:.3f}"
                    f" state={state}"
                    f" decision={decision}"
                )

                self._publish_decision(decision)

                self._last_loop_time = time.time()
                self._healthy = True
                self._last_error = None

                occupied_value = self.get_occupied() if self.get_occupied else 1
                #print(f"[TEST] {self.name} occupied_value = {occupied_value}")  # TEMP TEST PRINT — DELETE LATER
                if self.one_shot and decision == "0" and occupied_value != 0:
                    self._completed_normally = True
                    self._stop_event.set()
                    break

            except Exception as exc:  # noqa: BLE001 -- intentional: one bad cycle must never kill this thread
                self._healthy = False
                self._last_error = str(exc)
                print(f"[CLOSED_LOOP] {self.name} ERROR in control loop: {exc!r} -- retrying next cycle")

            time.sleep(self.loop_interval_s)

    # Converts a numeric ratio into under/over/good using target ± margin.
    def _get_state(self, ratio_value: float) -> str:
        lower_bound = self.target_ratio * (1 - self.margin)
        upper_bound = self.target_ratio * (1 + self.margin)

        if ratio_value < lower_bound:
            return "under"
        if ratio_value > upper_bound:
            return "over"
        return "good"

    # =================================================
    # RATIO-TO-COMMAND DECISION
    #
    # `under` requests Front, `over` requests Rear, and a stable in-band ratio
    # requests Stop.  The debounce values in config prevent noisy readings
    # from repeatedly changing direction.
    # =================================================
    def _evaluate(self, ratio_value: float) -> str:
        lower_bound = self.target_ratio * (1 - self.margin)
        upper_bound = self.target_ratio * (1 + self.margin)

        if ratio_value < lower_bound:
            self._under_count += 1
            self._over_count = 0
            self._good_count = 0
            if self._under_count >= self.debounce_under:
                return self.action_under
            if self._last_decision == "0":
                return self.action_under
            return self._last_decision

        if ratio_value > upper_bound:
            self._over_count += 1
            self._under_count = 0
            self._good_count = 0
            if self._over_count >= self.debounce_over:
                return self.action_over
            if self._last_decision == "0":
                return self.action_over
            return self._last_decision

        self._good_count += 1
        self._under_count = 0
        self._over_count = 0
        if self._good_count >= self.debounce_good:
            return "0"
        return self._last_decision

    # Publishes only transitions.  The pneumatic service owns its movement
    # ramp, so repeatedly sending the same direction would create MQTT noise.
    def _publish_decision(self, decision: str) -> None:
        # The pneumatic service self-manages the inflate/deflate ramp once a
        # direction is triggered, so repeating the same direction every loop
        # only spams redundant MQTT traffic and spawns duplicate movement threads.
        if decision == self._last_decision:
            return

        if decision != "0":
            published = self.publish_command(self.direction_topic, decision)
            # An empty-seat gate can decline the command.  Do not remember it
            # as sent, so the next loop retries once occupancy becomes nonzero.
            if published is False:
                return
            self._last_decision = decision
            return

        self.publish_command(self.stop_topic, "0")
        self._last_decision = "0"



# =====================================================
# ENGINE WATCHDOG
#
# This background monitor reports a dead or stalled bladder thread but never
# restarts it automatically.  That keeps recovery explicit during seat tests.
# =====================================================
# =====================================================
# ENGINE WATCHDOG
#
# This background monitor reports a dead or stalled bladder thread but never
# restarts it automatically.  That keeps recovery explicit during seat tests.
# =====================================================
class EngineWatchdog:
    """Warns when a BladderEngine thread dies or stops completing loop cycles.

    It only warns; it never restarts or modifies an engine automatically.
    """

    def __init__(
        self,
        get_active_engines: Callable[[], Dict[str, "BladderEngine"]],
        check_interval_s: float = 1.0,
        stall_threshold_s: float = 3.0,
    ):
        self.get_active_engines = get_active_engines
        self.check_interval_s = check_interval_s
        self.stall_threshold_s = stall_threshold_s
        self._stop_event = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._known_dead: set = set()

    # Starts the watchdog monitor thread once for the service lifetime.
    def start(self) -> None:
        self._stop_event.clear()
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=1.0)

    # Periodically checks thread liveness and the latest completed loop time.
    def _run(self) -> None:
        while not self._stop_event.is_set():
            for name, engine in self.get_active_engines().items():
                if engine._thread is not None and not engine._thread.is_alive():
                    if name not in self._known_dead:
                        if engine.completed_normally:
                            print(
                                f"[WATCHDOG] {name} finished normally "
                                f"(one_shot target reached) and its thread "
                                f"has exited cleanly."
                            )
                        else:
                            print(
                                f"[WATCHDOG] {name}'s control thread has DIED. "
                                f"Last error: {engine.last_error}. This bladder is now frozen "
                                f"until the mode is restarted."
                            )
                        self._known_dead.add(name)
                else:
                    self._known_dead.discard(name)
                    if engine.seconds_since_last_loop > self.stall_threshold_s:
                        print(
                            f"[WATCHDOG] {name} has not completed a loop iteration in "
                            f"{engine.seconds_since_last_loop:.1f}s "
                            f"(threshold {self.stall_threshold_s}s) -- it may be stuck."
                        )
            time.sleep(self.check_interval_s)


# =====================================================
# SENSOR-TO-RATIO MATH ENGINE
#
# Converts raw AiO offset frames into named ratios.  It does not send commands
# itself; BladderEngine reads its ratios.  The direct, unsmoothed data flow is:
# offsets -> mapped sensor groups -> totals -> configured ratios.
# =====================================================
class ClosedLoopEngine:
    def __init__(self, publish_command: Callable[[str, str], None], config: Optional[Dict[str, object]] = None):
        self.publish_command = publish_command
        cfg = config if (config and "sensor_to_index_mapping" in config) else CONFIG
        self.config = cfg
        self.sensor_mapping = cfg.get("sensor_to_index_mapping", {})
        self.sensor_groups = cfg.get("config_seat", {}).get("sensor_groups", {})
        self.bladder_names = set(
            cfg.get("config_seat", {}).get("bladder_pressure_groups", {})
        )
        self.ratio_formulas = cfg.get("ratio_formulas", {})
        self.control_settings = cfg.get("control", {})
        self._ratio_values: Dict[str, float] = {}
        self._lock = threading.Lock()
        self._has_aio_values = False

    # =================================================
    # RAW AIO FRAME PROCESSING
    #
    # TCPBridge supplies `offset` arrays here.  Mapping and formula details
    # live in config.yaml; this method intentionally uses the newest raw frame
    # without offset or ratio smoothing.
    # =================================================
    def update_offsets(self, offsets: List[int]) -> None:
        # The AiO frame is expected to carry at least 17 values.
        # Some real hardware provides 17 offsets instead of 20, so accept
        # shorter frames while still avoiding index errors.
        if len(offsets) < 17:
            print(f"[ClosedLoopEngine] dropped offset frame length={len(offsets)}")
            return

        if not self._has_aio_values:
            print(self.control_settings.get("waiting_message", "waiting for AiO values"))
            self._has_aio_values = True

        # Smoothing is intentionally disabled: use the newest AiO frame
        # directly for both the sensor-group sums and the final ratios.
        raw_offsets = [float(value) for value in offsets]

        group_values: Dict[str, float] = {}
        for group_name, sensors in self.sensor_groups.items():
            sensor_indices = [self.sensor_mapping.get(sensor) for sensor in sensors]
            valid_indices = [index for index in sensor_indices if index is not None]
            valid_values = [raw_offsets[index] for index in valid_indices if 0 <= index < len(raw_offsets)]
            if valid_values:
                group_values[group_name] = sum(valid_values)
            else:
                group_values[group_name] = 0.0

        totals = self._compute_totals(group_values)
        ratios = self._compute_ratios(group_values, totals)

        with self._lock:
            self._ratio_values = ratios

    # Resolves each declarative total in config to one named sensor-group sum.
    def _compute_totals(self, group_values: Dict[str, float]) -> Dict[str, float]:
        totals_config = self.ratio_formulas.get("totals", {})
        totals: Dict[str, float] = {}
        for total_name, group_name in totals_config.items():
            totals[total_name] = group_values.get(group_name, 0.0)
        return totals

    def _resolve_value(self, name: str, group_values: Dict[str, float], totals: Dict[str, float]) -> float:
        if name in totals:
            return totals[name]
        return group_values.get(name, 0.0)

    # =================================================
    # DECLARATIVE RATIO CALCULATION
    #
    # Each formula specifies a numerator and denominator by group/total name.
    # A `*_ratio` matching an active bladder is additionally stored under its
    # bare bladder name so BladderEngine can read it directly.
    # =================================================
    def _compute_ratios(self, group_values: Dict[str, float], totals: Dict[str, float]) -> Dict[str, float]:
        ratios_config = self.ratio_formulas.get("ratios", {})
        computed: Dict[str, float] = {}

        for ratio_name, spec in ratios_config.items():
            numerator_name = spec.get("numerator")
            denominator_spec: Union[str, List[str], None] = spec.get("denominator")

            numerator_value = self._resolve_value(numerator_name, group_values, totals)

            if isinstance(denominator_spec, list):
                denominator_value = sum(
                    self._resolve_value(name, group_values, totals) for name in denominator_spec
                )
            else:
                denominator_value = self._resolve_value(denominator_spec, group_values, totals)

            computed[ratio_name] = self._safe_divide(numerator_value, denominator_value)

        for ratio_name, value in list(computed.items()):
            if ratio_name.endswith("_ratio"):
                bare_name = ratio_name[: -len("_ratio")]
                if bare_name in self.bladder_names:
                    computed[bare_name] = value

        return computed

    # Returns the latest ratio used by a bladder's Front/Rear/Stop decision.
    def get_ratio(self, bladder_name: str) -> float:
        with self._lock:
            return self._ratio_values.get(bladder_name, 0.0)

    @staticmethod
    def _safe_divide(numerator: float, denominator: float) -> float:
        if denominator == 0:
            return 0.0
        return numerator / denominator
