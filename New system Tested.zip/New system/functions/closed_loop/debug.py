"""Standalone Tk debug dashboard for the closed-loop seat service.

This window is an independent, passive observer UI process.
It communicates exclusively over MQTT with the headless service:
- Receives live status snapshots on `Seat/ClosedLoop/Status`.
- Receives command logs on pneumatic / system topics.
- Sends mode switch requests on `SM/ClosedLoop/ActiveMode`.
- Sends reload triggers on `SM/ClosedLoop/ReloadConfig` after saving config.yaml.
"""

from __future__ import annotations

import json
import os
import queue
from collections import deque
from pathlib import Path
from typing import Any, Dict, Optional

import tkinter as tk
from tkinter import ttk

from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
from ruamel.yaml import YAML

from .app import (
    CONTROL_SETTINGS,
    DEBUG_ENABLED,
    MODE_DEFINITIONS,
    PROTOCOL_PUB_TOPICS,
    PROTOCOL_SUB_TOPICS,
    load_config,
    reload_config,
)
from network.mqtt import MQTT

HISTORY_LENGTH = 100
LOG_LENGTH = 200
PANELS_PER_ROW = 5
CONFIG_PATH = Path(__file__).with_name("config.yaml")
_yaml_rt = YAML()
_yaml_rt.preserve_quotes = True


# =====================================================
# ONE BLADDER DEBUG PANEL
#
# Each active bladder gets one Tkinter panel with a rolling ratio plot, its
# current command state, and an editable target.  The panel reads incoming
# status snapshots; it never talks to TCP or control logic directly.
# =====================================================
class BladderPanel:
    """Small per-bladder panel with ratio history and a target field."""

    def __init__(self, parent: ttk.Frame, name: str, target_ratio: float = 0.0, margin: float = 0.025) -> None:
        self.name = name
        self.target_ratio = target_ratio
        self.margin = margin
        self.history = deque(maxlen=HISTORY_LENGTH)
        self.zoomed = False
        self.frame = ttk.LabelFrame(parent, text=name.replace("_", " ").title(), padding=6)

        self.figure = Figure(figsize=(2.5, 1.55), dpi=100)
        self.axes = self.figure.add_subplot(111)
        self.axes.set_xlabel("samples", fontsize=7)
        self.axes.set_ylabel("ratio", fontsize=7)
        self.axes.tick_params(labelsize=7)
        self.axes.set_ylim(0, 1)
        (self.line,) = self.axes.plot([], [], color="gray", linewidth=1.5)
        self.target_line = self.axes.axhline(self.target_ratio, color="#4060a0", linestyle="--", linewidth=1)
        self.canvas = FigureCanvasTkAgg(self.figure, master=self.frame)
        self.canvas.get_tk_widget().pack(fill="x", expand=True)

        self.status_var = tk.StringVar(value="current: --    state: --")
        ttk.Label(self.frame, textvariable=self.status_var, width=34).pack(anchor="w", pady=(2, 0))

        self.fault_var = tk.StringVar(value="fault: none")
        ttk.Label(self.frame, textvariable=self.fault_var, width=34, wraplength=230).pack(anchor="w", pady=(0, 4))

        field = ttk.Frame(self.frame)
        field.pack(fill="x")
        ttk.Label(field, text="Target", width=11).grid(row=0, column=0, sticky="w")
        self.entry = ttk.Entry(field, width=10)
        self.entry.insert(0, str(self.target_ratio))
        self.entry.grid(row=0, column=1, sticky="ew", pady=1)
        field.columnconfigure(1, weight=1)
        self.entries = {"target_ratio": self.entry}

        self.zoom_button = ttk.Button(field, text="Zoom in", command=self.toggle_zoom)
        self.zoom_button.grid(row=0, column=2, padx=(6, 0), pady=1)

    def toggle_zoom(self) -> None:
        """Toggle an automatic y-axis close-up around the live values and target."""
        self.zoomed = not self.zoomed
        self.zoom_button.configure(text="Full scale" if self.zoomed else "Zoom in")
        self._set_y_limits(list(self.history))
        self.canvas.draw_idle()

    def _set_y_limits(self, values: list[float]) -> None:
        """Use either the normal 0--1 scale or a padded close-up around the data."""
        if not self.zoomed:
            upper = max(1.0, self.target_ratio * (1 + self.margin) * 1.15, *(values or [0.0]))
            self.axes.set_ylim(0, upper)
            return

        lower_target = self.target_ratio * (1 - self.margin)
        upper_target = self.target_ratio * (1 + self.margin)
        reference_values = [*values, self.target_ratio, lower_target, upper_target]
        lower = min(reference_values)
        upper = max(reference_values)

        # Keep a useful visible range even when every sample is identical.
        minimum_span = max(0.005, abs(self.target_ratio) * 0.05)
        span = max(upper - lower, minimum_span)
        padding = span * 0.15
        self.axes.set_ylim(max(0.0, lower - padding), upper + padding)

    def get_field_input(self, attribute: str) -> str:
        return self.entries[attribute].get()

    def mark_invalid(self, attribute: str, invalid: bool) -> None:
        self.entries[attribute].configure(style="Invalid.TEntry" if invalid else "TEntry")

    def update(self, ratio: float, target: float, state: str, faulted: bool, fault_reason: Optional[str]) -> None:
        self.target_ratio = target
        self.history.append(ratio)
        values = list(self.history)
        self.line.set_data(range(len(values)), values)
        self.axes.set_xlim(0, max(HISTORY_LENGTH - 1, len(values)))
        self._set_y_limits(values)

        lower_bound = self.target_ratio * (1 - self.margin)
        upper_bound = self.target_ratio * (1 + self.margin)
        in_target_band = lower_bound <= ratio <= upper_bound
        fault_text = fault_reason if faulted and fault_reason else "none"
        if faulted:
            color = "#b00020"
            status = f"current: {ratio:.4f}    state: Stop"
        elif state == "Stop" and in_target_band:
            color = "#228b22"
            status = f"current: {ratio:.4f}    state: Stop"
        elif state == "Stop":
            color = "#6f6f6f"
            status = f"current: {ratio:.4f}    state: Stop*"
        else:
            color = "#d95f02" if state == "Front" else "#1565c0"
            status = f"current: {ratio:.4f}    state: {state}"

        self.line.set_color(color)
        self.target_line.set_ydata([self.target_ratio, self.target_ratio])
        self.status_var.set(status)
        self.fault_var.set(f"fault: {fault_text}")
        self.canvas.draw_idle()


# =====================================================
# PASSIVE OBSERVER DEBUG DASHBOARD
#
# Displays live seat control data received over MQTT and sends user requests
# (mode switches, config reloads) back over MQTT. It does NOT hold references
# to ClosedLoopMain or TCPBridge, avoiding connection-stealing issues.
# =====================================================
class DebugDashboard:
    def __init__(
        self,
        root: tk.Tk,
        mqtt_client: Optional[MQTT] = None,
        command_log: Optional["queue.Queue[str]"] = None,
    ) -> None:
        self.root = root
        self.mqtt_client = mqtt_client
        self.command_log = command_log or queue.Queue()
        self.panels: Dict[str, BladderPanel] = {}

        self.active_mode: str = "none"
        self.latest_status: Dict[str, Dict[str, Any]] = {}

        style = ttk.Style()
        style.configure("Invalid.TEntry", fieldbackground="#ffd6d6")

        root.title("ClosedLoop Debug Dashboard <3")
        root.geometry("1450x900")
        root.protocol("WM_DELETE_WINDOW", self.close)

        self._build_controls()
        self._build_global_controls()
        self._build_scrollable_panels()
        self._build_log()
        self.update()

    def _build_controls(self) -> None:
        controls = ttk.Frame(self.root, padding=8)
        controls.pack(fill="x")
        ttk.Label(controls, text="Modes:").pack(side="left", padx=(0, 4))
        for mode_name in MODE_DEFINITIONS:
            ttk.Button(controls, text=mode_name, command=lambda name=mode_name: self.start_mode(name)).pack(side="left", padx=2)
        ttk.Button(controls, text="Stop All", command=self.stop_all).pack(side="left", padx=(10, 6))

        self.active_mode_var = tk.StringVar(value="Active mode: none")
        ttk.Label(controls, textvariable=self.active_mode_var).pack(side="right")

    def _build_global_controls(self) -> None:
        row_frame = ttk.Frame(self.root, padding=(8, 4))
        row_frame.pack(fill="x")

        global_frame = ttk.LabelFrame(row_frame, text="Global Settings", padding=8)
        global_frame.pack(side="left")

        inner = ttk.Frame(global_frame)
        inner.pack(fill="x")

        self.global_entries: Dict[str, ttk.Entry] = {}
        for label, key, default in (
            ("Margin", "default_margin", 0.025),
            ("Under", "default_debounce_under", 5),
            ("Over", "default_debounce_over", 5),
            ("Good", "default_debounce_good", 10),
        ):
            field = ttk.Frame(inner)
            field.pack(side="left", padx=6)
            ttk.Label(field, text=label).pack(side="left")
            entry = ttk.Entry(field, width=8)
            entry.insert(0, str(CONTROL_SETTINGS.get(key, default)))
            entry.pack(side="left")
            self.global_entries[key] = entry

        ttk.Button(inner, text="Apply", command=self.apply_all).pack(side="left", padx=(12, 4))
        self.global_status_var = tk.StringVar()
        ttk.Label(inner, textvariable=self.global_status_var).pack(side="left")

    def _build_scrollable_panels(self) -> None:
        outer = ttk.Frame(self.root, padding=(8, 0))
        outer.pack(fill="both", expand=True)
        self.canvas = tk.Canvas(outer, highlightthickness=0)
        scrollbar = ttk.Scrollbar(outer, orient="vertical", command=self.canvas.yview)
        self.panel_host = ttk.Frame(self.canvas)
        self.panel_host.bind("<Configure>", lambda _event: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.panel_window = self.canvas.create_window((0, 0), window=self.panel_host, anchor="nw")
        self.canvas.bind("<Configure>", lambda event: self.canvas.itemconfigure(self.panel_window, width=event.width))
        self.canvas.configure(yscrollcommand=scrollbar.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        for index in range(PANELS_PER_ROW):
            self.panel_host.columnconfigure(index, weight=1)

    def _build_log(self) -> None:
        log_frame = ttk.LabelFrame(self.root, text="Published MQTT commands", padding=6)
        log_frame.pack(fill="x", padx=8, pady=8)
        self.log_text = tk.Text(log_frame, height=8, state="disabled", wrap="none")
        scroll = ttk.Scrollbar(log_frame, orient="vertical", command=self.log_text.yview)
        self.log_text.configure(yscrollcommand=scroll.set)
        self.log_text.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

    def start_mode(self, mode_name: str) -> None:
        mode_topic = PROTOCOL_SUB_TOPICS.get("mode_switch_sub", "SM/ClosedLoop/ActiveMode")
        self.send_mqtt(mode_topic, mode_name)

    def stop_all(self) -> None:
        mode_topic = PROTOCOL_SUB_TOPICS.get("mode_switch_sub", "SM/ClosedLoop/ActiveMode")
        self.send_mqtt(mode_topic, "Stop")

    def send_mqtt(self, topic: str, payload: str) -> None:
        if self.mqtt_client:
            try:
                self.mqtt_client.send(topic, payload, 2, False)
                self.append_log(f"[SENT MQTT] {topic} -> {payload}")
            except Exception as exc:
                self.append_log(f"[MQTT ERROR] {exc}")
        else:
            self.append_log(f"[LOCAL] {topic} -> {payload}")

    def on_status_received(self, status_payload: Dict[str, Any]) -> None:
        self.active_mode = status_payload.get("active_mode", "none")
        self.latest_status = status_payload.get("bladders", {})

    def on_mode_received(self, mode_name: str) -> None:
        self.active_mode = mode_name
        if mode_name.lower() in {"stop", "none", "off", ""}:
            self.latest_status = {}
            self.rebuild_panels()
        self.active_mode_var.set(f"Active mode: {self.active_mode or 'none'}")

    def rebuild_panels(self) -> None:
        for panel in list(self.panels.values()):
            try:
                panel.frame.destroy()
            except Exception:
                pass
        self.panels.clear()
        margin = float(CONTROL_SETTINGS.get("default_margin", 0.025))
        for index, (name, bdata) in enumerate(list(self.latest_status.items())):
            target = bdata.get("target", 0.0)
            panel = BladderPanel(self.panel_host, name, target_ratio=target, margin=margin)
            panel.frame.grid(row=index // PANELS_PER_ROW, column=index % PANELS_PER_ROW, padx=5, pady=5, sticky="nsew")
            self.panels[name] = panel

    def append_log(self, message: str) -> None:
        self.log_text.configure(state="normal")
        self.log_text.insert("end", message + "\n")
        line_count = int(self.log_text.index("end-1c").split(".")[0])
        if line_count > LOG_LENGTH:
            self.log_text.delete("1.0", f"{line_count - LOG_LENGTH}.0")
        self.log_text.see("end")
        self.log_text.configure(state="disabled")

    def update(self) -> None:
        while True:
            try:
                self.append_log(self.command_log.get_nowait())
            except queue.Empty:
                break

        if set(self.latest_status.keys()) != set(self.panels.keys()):
            self.rebuild_panels()

        for name, bdata in self.latest_status.items():
            panel = self.panels.get(name)
            if panel is not None:
                ratio = bdata.get("current", bdata.get("ratio", 0.0))
                target = bdata.get("target", 0.0)
                state = bdata.get("state", "Stop")
                faulted = bdata.get("faulted", False)
                fault_reason = bdata.get("fault_reason")
                panel.update(ratio, target, state, faulted, fault_reason)

        self.active_mode_var.set(f"Active mode: {self.active_mode or 'none'}")
        self.root.after(250, self.update)

    def apply_all(self) -> None:
        from math import isfinite

        targets: Dict[str, float] = {}
        any_invalid = False

        for name, panel in self.panels.items():
            try:
                value = float(panel.get_field_input("target_ratio"))
                if not isfinite(value) or value < 0:
                    raise ValueError
                targets[name] = value
                panel.mark_invalid("target_ratio", False)
            except ValueError:
                panel.mark_invalid("target_ratio", True)
                any_invalid = True

        try:
            margin = float(self.global_entries["default_margin"].get())
            under = int(self.global_entries["default_debounce_under"].get())
            over = int(self.global_entries["default_debounce_over"].get())
            good = int(self.global_entries["default_debounce_good"].get())
            if not isfinite(margin) or margin < 0 or under < 1 or over < 1 or good < 1:
                raise ValueError
        except ValueError:
            any_invalid = True

        if any_invalid:
            self.global_status_var.set("Fix highlighted fields")
            return

        save_error = self._save_to_config(targets, margin, under, over, good)
        if save_error is None:
            reload_topic = PROTOCOL_PUB_TOPICS.get("reload_config_pub", "SM/ClosedLoop/ReloadConfig")
            self.send_mqtt(reload_topic, "reload")
            self.global_status_var.set("Saved & Reloaded")
            self.root.after(2000, lambda: self.global_status_var.set(""))
        else:
            self.global_status_var.set(f"Save failed: {save_error}"[:90])

    def _save_to_config(self, targets, margin, under, over, good) -> Optional[str]:
        try:
            with open(CONFIG_PATH, "r", encoding="utf-8") as handle:
                data = _yaml_rt.load(handle)

            active_mode = self.active_mode
            if active_mode and active_mode in data.get("modes", {}):
                mode_targets = data["modes"][active_mode].setdefault("targets", {})
                for name, value in targets.items():
                    mode_targets[name] = value

            data["control"]["default_margin"] = margin
            data["control"]["default_debounce_under"] = under
            data["control"]["default_debounce_over"] = over
            data["control"]["default_debounce_good"] = good

            tmp_path = CONFIG_PATH.with_suffix(".tmp")
            with open(tmp_path, "w", encoding="utf-8") as handle:
                _yaml_rt.dump(data, handle)
            os.replace(tmp_path, CONFIG_PATH)
            reload_config()
            return None
        except Exception as exc:
            error_message = f"{type(exc).__name__}: {exc}"
            print(f"[_save_to_config] error: {error_message}")
            return error_message

    def close(self) -> None:
        if self.mqtt_client:
            try:
                self.mqtt_client.disconnect()
            except Exception:
                pass
        self.root.destroy()


# =====================================================
# STANDALONE DEBUG ENTRY POINT
# =====================================================
def main() -> None:
    if not DEBUG_ENABLED:
        print("[DEBUG] Debug window disabled in config. Set 'debug: true' to enable it.")
        return

    config = load_config()
    mqtt_cfg = config.get("protocol", {})

    command_log: "queue.Queue[str]" = queue.Queue()
    mqtt_conf = {**mqtt_cfg, "sub_topics": mqtt_cfg.get("sub_topics", {})}
    mqtt_conf["function"] = "ClosedLoopDebug"
    mqtt_client = MQTT(mqtt_conf)

    root = tk.Tk()
    dashboard = DebugDashboard(root, mqtt_client=mqtt_client, command_log=command_log)

    status_topic = PROTOCOL_PUB_TOPICS.get("status_pub", "Seat/ClosedLoop/Status")
    mode_topic = PROTOCOL_SUB_TOPICS.get("mode_switch_sub", "SM/ClosedLoop/ActiveMode")

    def _on_mqtt_msg(message):
        topic = message.topic
        payload = message.payload.decode("utf-8", errors="ignore") if isinstance(message.payload, bytes) else str(message.payload)
        
        if topic == status_topic:
            try:
                data = json.loads(payload)
                dashboard.on_status_received(data)
            except Exception as exc:
                print(f"[DEBUG] Status JSON parse error: {exc}")
        elif topic == mode_topic:
            mode_name = payload.strip()
            dashboard.on_mode_received(mode_name)
            command_log.put(f"[RECV MQTT] {topic} -> {payload}")
        else:
            command_log.put(f"[RECV MQTT] {topic} -> {payload}")

    mqtt_client.set_on_receive_callback(_on_mqtt_msg)

    try:
        root.mainloop()
    finally:
        try:
            mqtt_client.disconnect()
        except Exception:
            pass


if __name__ == "__main__":
    main()
