import os
import logging
import re
import threading
import can
from typing import Dict, Any, List
import time
from functions.msm.utils.dbc_loader import DBCLoader
from functions.msm.motor_controller import MotorController
from network.protocol_factory import ProtocolFactory


class MSM:
    """MSM class focused on protocol communication and message routing."""

    def __init__(self, config: Dict[str, Any], protocol=None):
        os.chdir(os.path.abspath(os.path.dirname(__file__)))
        super().__init__()
        self.logger = logging.getLogger(f"{__name__}_{__class__.__name__}")
        self.config = config
        self.protocol = protocol

        # Initialize MQTT protocol communication
        self.sub_topics = self.config.get("protocol").get("sub_topics")
        self.pub_topics = self.config.get("protocol").get("pub_topics")
        self.logger.info(f"Subscribing to topics: {self.sub_topics}")
        self.protocol.subscribe()
        self.protocol.set_on_receive_callback(self.mqtt_on_message)
        self.dbc_loader = DBCLoader()
        self.motor_aliases = self.config.get("motor_aliases", {})
        self.motor_aliases_inverse = {v: k for k, v in self.motor_aliases.items()}
        
        # Get list of motors that need inversion from config
        self.inverted_motors = self.config.get("inverted_motors", [])
        self.logger.info(f"Motors configured for inversion: {self.inverted_motors}")
        
        # Initialize motor controller (no protocols, just data handling)
        self.motor_controller = MotorController(
            config=config,
            dbc_loader=self.dbc_loader
        )
        self.position_threads = {}
        self.position_thread_flags = {}
        
        # ADD: Thread lock for protecting shared motor state
        self.motor_state_lock = threading.Lock()

        # Initialize CAN protocol
        self.protocol_can = ProtocolFactory.create_instance(self.config.get("protocol_can"))
        self.protocol_can.connect()
        self.protocol_can.add_listener(self.on_can_receive)
        
        # Extract motors configured for this MSM service
        self.service_motors = set()

        for ecu in self.config.get("ecus", []):
            for motor in ecu.get("motors", []):
                self.service_motors.add(motor)

        self.logger.info(f"Motors enabled for this MSM service: {self.service_motors}")

        # Initialize DBC loader
        self.logger.info("MSM initialized successfully")
        for motor in self.motor_controller.get_motors():
                self._send_speed_command(motor, 100)
                time.sleep(0.1)
        self.is_ready = True

    def _is_motor_inverted(self, motor_name: str) -> bool:
        """Check if a motor should have its percentage values inverted."""
        return (motor_name in self.inverted_motors or 
                self.motor_aliases.get(motor_name) in self.inverted_motors or
                self.motor_aliases_inverse.get(motor_name) in self.inverted_motors)
    
    def _invert_direction_if_needed(self, motor_name: str, direction: int) -> int:
        """Invert direction value if motor is configured for inversion."""
        if self._is_motor_inverted(motor_name) and direction in [1, 2]:
            inverted = 2 if direction == 1 else 1
            self.logger.info(f"Inverted {motor_name} direction: {direction} -> {inverted}")
            return inverted
        return direction

    def _invert_percentage_if_needed(self, motor_name: str, percentage: int) -> int:
        """Invert percentage value if motor is configured for inversion."""
        if self._is_motor_inverted(motor_name) and 0 <= percentage <= 100:
            inverted = 100 - percentage
            self.logger.info(f"Inverted {motor_name} percentage: {percentage} -> {inverted}")
            return inverted
        return percentage

    def mqtt_on_message(self, message):
        """Handle incoming MQTT messages and route them to appropriate motor commands."""
        topic = message.topic
        payload = message.payload.decode()
        self.logger.info(f"MQTT message on topic {topic}: {payload}")

        if message.topic == self.sub_topics.get("check_is_ready_sub"):
            self.check_is_ready()
        else:
            match = re.match(r"SM/MSM/Set_(\w+)/(Speed|Direction|Learn|Position|SoftStartStop)", topic)
            if not match:
                self.logger.warning(f"Unrecognized MQTT topic: {topic}")
                return
    
            motor_name, cmd = match.groups()
            motor_name = self.motor_aliases.get(motor_name, motor_name) 
            
            try:
                if cmd == "Speed":
                    self.logger.info(f"Received speed command for {motor_name}: {payload}")
                    speed = int(payload)
                    self._send_speed_command(motor_name, speed)
    
                elif cmd == "Direction":
                    self.logger.info(f"Received direction command for {motor_name}: {payload}")
                    direction = int(payload)
                    direction = self._invert_direction_if_needed(self.motor_aliases_inverse.get(motor_name, motor_name), direction)
                    self._send_direction_command(motor_name, direction)
    
                elif cmd == "Position":
                    self.logger.info(f"Received position command for {motor_name}: {payload}")
                    position = int(payload)
                    inverted_position = self._invert_percentage_if_needed(self.motor_aliases_inverse.get(motor_name, motor_name), position)
    
                    if inverted_position != position:
                        self.logger.info(f"Inverted position command for {motor_name}: {position} -> {inverted_position}")
    
                    self._send_position_command(motor_name, inverted_position)
    
                elif cmd == "SoftStartStop":
                    self.logger.info(f"Received soft start/stop command for {motor_name}: {payload}")
                    value = int(payload)
                    self._send_soft_start_stop_command(motor_name, value)
    
                elif cmd == "Learn":
                    self.logger.info(f"Received learning command for {motor_name}: {payload}")
                    self._send_speed_command(motor_name, 100)
                    time.sleep(0.1)
                    self._send_learning_request(motor_name)
    
            except ValueError as e:
                self.logger.error(f"Invalid payload format for {cmd} command on {motor_name}: {payload}. Error: {e}")
            except Exception as e:
                self.logger.error(f"Error handling MQTT {cmd} for {motor_name}: {e}")
                
    def check_is_ready(self):
        """Publish readiness state via protocol if ready."""
        if self.is_ready:
            self.protocol.send(self.pub_topics.get("is_ready_pub"), self.__class__.__name__, 2, False)

    def _send_speed_command(self, motor_name: str, speed: int):
        """Send speed command to motor via CAN with thread-safe state access."""
        with self.motor_state_lock:
            command_data = self.motor_controller.prepare_speed_command(motor_name, speed)
            if command_data:
                self._send_can_command(command_data)

    def _send_position_command(self, motor_name: str, position: int):
        """Send position command to motor via CAN."""
        with self.motor_state_lock:
            command_data = self.motor_controller.prepare_position_command(motor_name, position)
            
            # FIX TO TEST
        command_data['signal_dict']['CommandARMHeightSetpointCmd'] = 102
        command_data['signal_dict']['ReclineSetpointCmd'] = 102
        
        if command_data:
            time.sleep(0.05)
            self._send_can_command(command_data)
            time.sleep(0.05)
            self._send_can_command(command_data)
            time.sleep(0.05)
            self._send_can_command(command_data)

            self._start_soft_position_thread(motor_name, position)
   
    def _soft_position_control(
        self,
        motor_name: str,
        target_position: int,
        stop_event,
        max_speed: int = 100,
        ramp_step: int = 10,
        ramp_delay: float = 0.1,
        slow_down_threshold: int = 15
    ):
        """
        Soft start / soft stop speed controller for one motor.
        Thread-safe implementation that properly manages shared state.
        """
        self.logger.info(
            f"Soft position control started for {motor_name}, target={target_position}"
        )

        speed = 0

        # ---------- EARLY EXIT ----------
        current = self.motor_controller.get_motor_position(motor_name)
        if current is not None and abs(target_position - current) <= 1:
            self.logger.info(
                f"{motor_name} already at target position {target_position}"
            )
            return

        # ---------- SOFT START ----------
        while speed < max_speed and not stop_event.is_set():
            speed = min(speed + ramp_step, max_speed)
            # Thread-safe speed command
            with self.motor_state_lock:
                command_data = self.motor_controller.prepare_speed_command(motor_name, speed)
            if command_data:
                self._send_can_command(command_data)
            time.sleep(ramp_delay)

        # ---------- CRUISE ----------
        while not stop_event.is_set():
            current = self.motor_controller.get_motor_position(motor_name)
            if current is None:
                time.sleep(0.05)
                continue

            distance = abs(target_position - current)

            if distance <= slow_down_threshold:
                break

            time.sleep(0.05)

        # ---------- SOFT STOP ----------
        while speed > 0 and not stop_event.is_set():
            speed = max(speed - ramp_step, 0)
            # Thread-safe speed command
            with self.motor_state_lock:
                command_data = self.motor_controller.prepare_speed_command(motor_name, speed)
            if command_data:
                self._send_can_command(command_data)
            time.sleep(ramp_delay)

        self.logger.info(
            f"Soft position control finished for {motor_name}"
        )
        
    def _start_soft_position_thread(self, motor_name: str, position: int):
        """
        Start soft position control.
        Cancels only the thread of the same motor.
        """
        # Cancel existing thread for this motor
        if motor_name in self.position_thread_flags:
            self.logger.info(
                f"Cancelling existing soft control thread for {motor_name}"
            )
            self.position_thread_flags[motor_name].set()

        stop_event = threading.Event()
        self.position_thread_flags[motor_name] = stop_event

        thread = threading.Thread(
            target=self._soft_position_control,
            args=(motor_name, position, stop_event),
            daemon=True
        )

        self.position_threads[motor_name] = thread
        thread.start()
   
    def _send_direction_command(self, motor_name: str, direction: int):
            command_data = self.motor_controller.prepare_direction_command(motor_name, direction)
            if command_data:
                self._send_can_command(command_data)

    def _send_soft_start_stop_command(self, motor_name: str, value: int):
        """Send soft start/stop command to motor via CAN."""
        with self.motor_state_lock:
            command_data = self.motor_controller.prepare_soft_start_stop_command(motor_name, value)
            if command_data:
                self._send_can_command(command_data)

    def _send_learning_request(self, motor_name: str):
        """Send learning request to motor via CAN."""
        with self.motor_state_lock:
            data_packets = self.motor_controller.prepare_learning_request(motor_name)
            msg_id, extended_session = self.motor_controller.enter_extended_session()
        
        msg = can.Message(arbitration_id=msg_id, data=extended_session, is_extended_id=True)
        self.protocol_can.send(msg)
        self.logger.info(f"Sent CAN message: {msg}")
        time.sleep(0.02)
        
        if data_packets:
            for packet in data_packets:
                time.sleep(0.02)
                self._send_can_learning_packet(packet)

    def _send_can_command(self, command_data: Dict[str, Any]):
        """Send a regular CAN command message."""
        try:
            ecu_id = command_data["ecu_id"]
            message_name = command_data["message_name"]
            signal_dict = command_data["signal_dict"]

            # Get message info from motor controller
            msg_info = self.motor_controller.get_message_info(ecu_id, message_name)
            if not msg_info:
                self.logger.error(f"Could not get message info for {message_name} on ECU {ecu_id}")
                return

            msg_id = msg_info["msg_id"]
            db = msg_info["db"]

            # Encode the message
            data = db.encode_message(msg_id, signal_dict)
            self.logger.info(f"Encoded data: {data}")

            # Create and send the CAN message
            msg = can.Message(arbitration_id=msg_id, data=data, is_extended_id=True)
            self.protocol_can.send(msg)
            self.logger.info(f"Sent CAN message: {msg}")

        except Exception as e:
            self.logger.error(f"Failed to send CAN command: {e}")

    def _send_can_learning_packet(self, packet_data: Dict[str, Any]):
        """Send a learning request CAN packet."""
        try:
            message_id = packet_data["message_id"]
            data = packet_data["data"]
            msg = can.Message(arbitration_id=message_id, data=data, is_extended_id=True)
            self.protocol_can.send(msg)
            self.logger.info(f"Sent CAN learning packet: {msg}")

        except Exception as e:
            self.logger.error(f"Failed to send CAN learning packet: {e}")

    def on_can_receive(self, message):
        """Handle incoming CAN messages."""
        # Thread-safe message processing
        motor_updates = self.motor_controller.process_can_message(message.arbitration_id, message.data)
        
        if motor_updates:
            self._publish_motor_updates(motor_updates)

    def _publish_motor_updates(self, motor_updates: Dict[str, Dict[str, Any]]):
        """Publish motor status updates via MQTT and check if requested position is reached."""
        for motor_name, update_info in motor_updates.items():
            if motor_name not in self.service_motors:
                self.logger.info(
                    f"Ignoring publish for motor {motor_name} "
                    f"(not configured for this MSM service)"
                )
                continue

            data_type = update_info["type"]
            value = update_info["value"]

            publish_motor_name = self.motor_aliases_inverse.get(motor_name, motor_name)
            topic = f"MSM/SM/Get_{publish_motor_name}/{data_type}"

            inverted_position = self._invert_percentage_if_needed(
                self.motor_aliases_inverse.get(motor_name, motor_name),
                value
            )

            if inverted_position != value:
                self.logger.info(
                    f"Inverted position command for {motor_name}: "
                    f"{value} -> {inverted_position}"
                )

            self.protocol.send(topic, str(inverted_position), 2, True)
            self.logger.info(
                f"Published {publish_motor_name} {data_type} "
                f"{inverted_position} to {topic}"
            )

            if data_type.lower() == "percentage":
                reached = self.motor_controller.has_reached_requested_position(
                    motor_name, inverted_position
                )
                reached_topic = f"MSM/SM/Get_{publish_motor_name}/ReachedPosition"
                if reached:
                    self.logger.info(
                        f"Published {publish_motor_name} reached status "
                        f"{reached} to {reached_topic}"
                    )

    def disconnect(self):
        """Clean up connections."""
        try:
            # Stop all position control threads
            for motor_name, stop_event in self.position_thread_flags.items():
                stop_event.set()
            
            # Wait for threads to finish
            for motor_name, thread in self.position_threads.items():
                if thread.is_alive():
                    thread.join(timeout=2.0)
            
            if hasattr(self, 'protocol') and self.protocol:
                self.protocol.disconnect()
            if hasattr(self, 'protocol_can') and self.protocol_can:
                self.protocol_can.disconnect()
            self.logger.info("MSM disconnected successfully")
        except Exception as e:
            self.logger.error(f"Error during disconnect: {e}")