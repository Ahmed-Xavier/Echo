import os
import logging
from typing import Dict, Any
from network.protocol_factory import ProtocolFactory
import os
import time

class Seat_Buttons:

    def __init__(self, config: Dict[str, Any], protocol=None):
        self.logger = logging.getLogger(f'{__name__}_{self.__class__.__name__}')
        self.logger.setLevel(logging.DEBUG)
        os.chdir(os.path.abspath(os.path.dirname(__file__)))
        
        self.config = config
        # self.logger.info(f"Initializing Seat_Buttons with config: {self.config}")
        
        self.protocol = protocol
        self.sub_topics = self.config.get('protocol').get('sub_topics')
        self.pub_topics = self.config.get('protocol').get('pub_topics')
        
        self.protocol.set_on_receive_callback(self.mqtt_on_message)
        self.protocol.subscribe()

        mcp3008_device_path             = self.config.get('buttons_config').get('mcp3008_device_path') 
        
        self.adc_margin                 = self.config.get('buttons_config').get('adc_margin')

        self.track_height_off_value     = self.config.get('buttons_config').get('track_height_off_value')
        self.backrest_tilt_off_value    = self.config.get('buttons_config').get('backrest_tilt_off_value')
        self.cla_off_value              = self.config.get('buttons_config').get('cla_off_value')
        self.bolsters_off_value         = self.config.get('buttons_config').get('bolsters_off_value')

        self.track_forward_value        = self.config.get('buttons_config').get('track_forward_value')
        self.track_backward_value       = self.config.get('buttons_config').get('track_backward_value')
        self.height_up_value            = self.config.get('buttons_config').get('height_up_value')
        self.height_down_value          = self.config.get('buttons_config').get('height_down_value')

        self.backrest_up_value          = self.config.get('buttons_config').get('backrest_up_value')
        self.backrest_down_value        = self.config.get('buttons_config').get('backrest_down_value')
        self.tilt_up_value              = self.config.get('buttons_config').get('tilt_up_value')
        self.tilt_down_value            = self.config.get('buttons_config').get('tilt_down_value')

        self.cla_forward_value          = self.config.get('buttons_config').get('cla_forward_value')
        self.cla_backward_value         = self.config.get('buttons_config').get('cla_backward_value')

        self.bolsters_up_value          = self.config.get('buttons_config').get('bolsters_up_value')
        self.bolsters_down_value        = self.config.get('buttons_config').get('bolsters_down_value')
        self.bolsters_right_value       = self.config.get('buttons_config').get('bolsters_right_value')
        self.bolsters_left_value        = self.config.get('buttons_config').get('bolsters_left_value')
        self.bolsters_central_value     = self.config.get('buttons_config').get('bolsters_central_value')
        
        input_chan_track_height         = self.config.get('buttons_config').get('input_channel_track_height')
        input_chan_backrest_tilt        = self.config.get('buttons_config').get('input_channel_backrest_tilt')
        input_chan_cla                  = self.config.get('buttons_config').get('input_channel_cla')
        input_chan_bolsters             = self.config.get('buttons_config').get('input_channel_bolsters')
        
        adc_path_track_height           = f'{mcp3008_device_path}/in_voltage{input_chan_track_height}_raw'
        adc_path_backrest_tilt          = f'{mcp3008_device_path}/in_voltage{input_chan_backrest_tilt}_raw'
        adc_path_cla                    = f'{mcp3008_device_path}/in_voltage{input_chan_cla}_raw'
        adc_path_bolsters               = f'{mcp3008_device_path}/in_voltage{input_chan_bolsters}_raw'

        self.chan_track_height          = open(adc_path_track_height, 'r')
        self.chan_backrest_tilt         = open(adc_path_backrest_tilt, 'r')
        self.chan_cla                   = open(adc_path_cla, 'r')
        self.chan_bolsters              = open(adc_path_bolsters, 'r')

        self.control_systems = {
            'track_height': {
                'off_value': self.track_height_off_value,
                'actions': {
                    'Track FORWARD': self.track_forward_value,
                    'Track BACKWARD': self.track_backward_value,
                    'Height UP': self.height_up_value,
                    'Height DOWN': self.height_down_value
                }
            },
            'backrest_tilt': {
                'off_value': self.backrest_tilt_off_value,
                'actions': {
                    'Backrest UP': self.backrest_up_value,
                    'Backrest DOWN': self.backrest_down_value,
                    'Tilt UP': self.tilt_up_value,
                    'Tilt DOWN': self.tilt_down_value
                }
            },
            'cla': {
                'off_value': self.cla_off_value,
                'actions': {
                    'CLA FORWARD': self.cla_forward_value,
                    'CLA BACKWARD': self.cla_backward_value
                }
            },
            'bolsters': {
                'off_value': self.bolsters_off_value,
                'actions': {
                    'Bolsters UP': self.bolsters_up_value,
                    'Bolsters DOWN': self.bolsters_down_value,
                    'Bolsters RIGHT': self.bolsters_right_value,
                    'Bolsters LEFT': self.bolsters_left_value,
                    'Bolsters CENTRAL': self.bolsters_central_value
                }
            }
        }
        
        # Track multiple simultaneous button presses using sets
        self.last_actions = {
            'track_height': set(),
            'backrest_tilt': set(), 
            'cla': set(),
            'bolsters': set()
        }
        
        self.do_loop()
    
    def mqtt_on_message(self, message):
        self.logger.debug(f"{message.topic}: {message.payload.decode()}")
        if message.topic == self.sub_topics["reset_sub"]:
            self.reset()

        
    def is_value_in_range(self, target_value, reference_value, margin):
        """Check if target_value is within margin of reference_value"""
        return reference_value - margin <= target_value <= reference_value + margin
    
    def is_system_active(self, adc_value, off_value):
        """Check if the control system is active (not in off position)"""
        return adc_value <= off_value - self.adc_margin
    
    def detect_all_actions(self, adc_value, system_name):
        """Detect ALL actions being performed for a given system"""
        system_config = self.control_systems[system_name]
        active_actions = set()
        
        # Check if system is active
        if not self.is_system_active(adc_value, system_config['off_value']):
            return active_actions
        
        # Find ALL matching actions (not just the first one)
        for action_name, action_value in system_config['actions'].items():
            if self.is_value_in_range(action_value, adc_value, self.adc_margin):
                active_actions.add(action_name)
        
        return active_actions
    
    def _get_bolsters_message(self, action):
        """Get appropriate message for bolsters actions"""
        if "UP" in action:
            return "1"
        elif "DOWN" in action:
            return "2"
        elif "RIGHT" in action:
            return "3"
        elif "LEFT" in action:
            return "4"
        elif "CENTRAL" in action:
            return "5"
        return "0"

    def _send_action_message(self, action, event_type):
        """Helper method to send MQTT messages for button events"""
        print(f"{action} {event_type}")
        
        # Get the topic
        topic_key = f"{(action.split(' ')[0]).lower()}_pub"
        topic = self.pub_topics.get(topic_key)
        
        if not topic:
            self.logger.warning(f"No topic found for action: {action}")
            return
        # Determine message content
        if "Bolsters" in action:
            # Handle bolsters-specific logic
            if event_type == "PRESSED":
                msg = self._get_bolsters_message(action)
            else:  # RELEASED
                msg = "STOP"
        else:
            # Handle other actions
            if event_type == "PRESSED":
                action_upper = action.upper()
                if "UP" in action_upper:
                    msg = "UP"
                elif "FORWARD" in action_upper:
                    msg = "FORWARD"
                elif "DOWN" in action_upper:
                    msg = "DOWN"
                elif "BACKWARD" in action_upper:
                    msg = "BACKWARD"
                else:
                    msg = "STOP"
            else:  # RELEASED
                msg = "STOP"
        
        self.protocol.send(topic, msg, 2, True)
    
    def process_all_controls(self, adc_track_height_value, adc_backrest_tilt_value, 
                         adc_cla_value, adc_bolsters_value):
        """Process all control inputs and handle multiple simultaneous button presses"""
        
        adc_inputs = {
            'track_height': adc_track_height_value,
            'backrest_tilt': adc_backrest_tilt_value,
            'cla': adc_cla_value,
            'bolsters': adc_bolsters_value
        }
        
        for system_name, adc_value in adc_inputs.items():
            current_actions = self.detect_all_actions(adc_value, system_name)
            previous_actions = self.last_actions[system_name]
            
            # Find newly pressed buttons
            newly_pressed = current_actions - previous_actions
            
            # Find newly released buttons  
            newly_released = previous_actions - current_actions
            
            # Handle newly pressed buttons
            for action in newly_pressed:
                self._send_action_message(action, "PRESSED")
                # print(f"{action} PRESSED")
            
            # Handle newly released buttons
            for action in newly_released:
                self._send_action_message(action, "RELEASED")
                # print(f"{action} RELEASED")
            
            # Update the state
            self.last_actions[system_name] = current_actions
    
    def do_loop(self):
        while True:
            try:
                self.chan_track_height.seek(0)
                self.chan_backrest_tilt.seek(0)
                self.chan_cla.seek(0)
                self.chan_bolsters.seek(0)

                adc_track_height_value = int(self.chan_track_height.readline().rstrip('\n'))
                adc_backrest_tilt_value = int(self.chan_backrest_tilt.readline().rstrip('\n'))
                adc_cla_value = int(self.chan_cla.readline().rstrip('\n'))
                adc_bolsters_value = int(self.chan_bolsters.readline().rstrip('\n'))
                
                # Debug output (uncomment if needed)
                # print(f"ADC values - Track/Height: {adc_track_height_value}, Backrest/Tilt: {adc_backrest_tilt_value}, CLA: {adc_cla_value}, Bolsters: {adc_bolsters_value}")
                
                self.process_all_controls(adc_track_height_value, adc_backrest_tilt_value, 
                                        adc_cla_value, adc_bolsters_value)
                         
            except (ValueError, IOError) as e:
                self.logger.error(f"Error reading ADC values: {e}")
                
            time.sleep(.05)

    def reset(self):
        self.logger.info("Resetting service Seat Buttons...")
        # Reset all tracked actions
        for system_name in self.last_actions:
            self.last_actions[system_name] = set()
    
    def on_exit(self):
        try:
            # Close file handles
            self.chan_track_height.close()
            self.chan_backrest_tilt.close()
            self.chan_cla.close()
            self.chan_bolsters.close()
        except Exception as e:
            self.logger.error(f"Error closing file handles: {e}")
        
        self.protocol.disconnect()