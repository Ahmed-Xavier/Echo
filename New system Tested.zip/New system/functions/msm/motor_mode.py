from enum import Enum

class MotorMode(Enum):
    IDLE = "idle"
    POSITIONING = "positioning"
    LEARNING = "learning"
    STOPPING = "stopping"
