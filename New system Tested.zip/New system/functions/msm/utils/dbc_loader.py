import cantools
import os


class DBCLoader:
    def __init__(self):
        self.dbs = {}
        self.message_ids = {}

    def load_dbc(self, file_path, ecu_id):
        """Load DBC file for specific ECU and store all message IDs."""
        try:
            if not os.path.exists(file_path):
                raise FileNotFoundError(f"DBC file not found: {file_path}")

            db = cantools.database.load_file(file_path)
            self.dbs[ecu_id] = db

            # Store all message IDs
            ecu_message_ids = {message.name: message.frame_id for message in db.messages}
            self.message_ids[ecu_id] = ecu_message_ids

            return db, True, f"DBC file loaded successfully for ECU {ecu_id}"

        except Exception as e:
            self.dbs.pop(ecu_id, None)
            self.message_ids.pop(ecu_id, None)
            return None, False, str(e)

    def get_message_ids(self, ecu_id=None):
        if ecu_id is not None:
            return self.message_ids.get(ecu_id, {}).copy()
        return self.message_ids.copy()
