import logging
from typing import Dict, Any, Optional, List, Callable
import threading


class MotorController:
    """Motor controller that handles motor data, logic, and message preparation."""

    SEAT_COMMANDS_ALL = "Seat_Commands_ALL"  # Message name for seat commands
    SEAT_STATUS_STC = "Seat_Status_STC"  # Message name for seat status
    UDS_SENDING_ID = 0x18DA56F9
    UDS_RECEIVING_ID = 0x18DAF956
    
    def __init__(self, config: Dict[str, Any], dbc_loader):
        """
        Initialize the motor controller.

        Args:
            config: Configuration dictionary containing ECUs, signals, etc.
            dbc_loader: DBC loader instance
        """
        self.logger = logging.getLogger(f"{__name__}_{__class__.__name__}")
        self.config = config
        self.dbc_loader = dbc_loader

        # Initialize motor-related configurations
        self.ecus = config.get("ecus", [])
        self.ecu_arbitration_map = {}  # map feedback CAN ID → ECU number
        self.motors_dbs = {}  # {motor: db}
        self.mux_bytes_per_ecu = {}  # {ecu_id: mux_byte}

        # Signal mappings
        self.position_signals = config.get("position_signals", {})
        self.speed_signals = config.get("speed_signals", {})
        self.direction_signals = config.get("direction_signals", {})
        self.soft_start_stop_signals = config.get("soft_start_stop_signals", {})
        self.speed_status_signals = config.get("speed_status_signals", {})
        self.percentage_status_signals = config.get("percentage_status_signals", {})
        self.learning_pb = config.get("learning", {})

        # Motor state tracking
        self.motor_speeds = {}  # Map motor name to its current speed
        self.motor_positions = {}  # Map motor name to its current position
        self.motors = []
        self.last_requested_positions = {}
        self.last_requested_speeds = {}
        self.last_requested_directions = {}
        self._state_lock = threading.Lock()
        # Initialize ECUs and DBC files
        self._initialize_ecus()

    def _initialize_ecus(self):
        """Initialize ECU configurations and load DBC files."""
        for ecu in self.ecus:
            ecu_id = ecu.get("id")
            dbc_path = ecu.get("dbc_path")
            if not hasattr(self, "motors"):
                self.motors = []
            # Add new motors from ecu
            self.motors.extend(ecu.get("motors", []))
            motors = ecu.get("motors", [])
            mux_bytes = ecu.get("mux_bytes", {})

            self.logger.info(f"Loading DBC for ECU {ecu_id} from path: {dbc_path}")
            db, success, message = self.dbc_loader.load_dbc(dbc_path, ecu_id)

            if success:
                self.logger.info(message)
                feedback_id = self.dbc_loader.get_message_ids(ecu_id).get(self.SEAT_STATUS_STC)
                self.ecu_arbitration_map[feedback_id] = ecu_id
                self.logger.info(f"Feedback ID for ECU {ecu_id}: {feedback_id}")

                for motor in motors:
                    self.motors_dbs[motor] = db

                self.mux_bytes_per_ecu[ecu_id] = mux_bytes
            else:
                self.logger.error(f"Failed to load DBC for ECU {ecu_id}: {message}")

    # Motor command preparation methods - return data for MSM to send
    def prepare_position_command(self, motor_name: str, value: int) -> Optional[Dict[str, Any]]:
        self.last_requested_positions[motor_name] = value
        return self._prepare_motor_command(motor_name, value, "position_signals", "seat_set_point_commands")

    def prepare_speed_command(self, motor_name: str, value: int) -> Optional[Dict[str, Any]]:
        self.last_requested_speeds[motor_name] = value
        return self._prepare_motor_command(motor_name, value, "speed_signals", "seat_speed_commands")

    def prepare_direction_command(self, motor_name: str, value: int) -> Optional[Dict[str, Any]]:
        self.last_requested_directions[motor_name] = value
        return self._prepare_motor_command(motor_name, value, "direction_signals", "seat_direction_commands")

    def prepare_soft_start_stop_command(self, motor_name: str, value: int) -> Optional[Dict[str, Any]]:
        """Prepare soft start/stop command data for a motor."""
        return self._prepare_motor_command(motor_name, value, "soft_start_stop_signals",
                                           "seat_soft_start_stop_commands")

    def prepare_learning_request(self, motor_name: str) -> Optional[List[Dict[str, Any]]]:
        """Prepare learning request data for a specific motor."""
        try:
            ecu_id = self._get_ecu_id_by_motor(motor_name)
            learning_requests = self.learning_pb.get(motor_name, [0, 0, 0, 0, 0])

            first_frame = [0x10, 0x09, 0x31, 0x01, 0xCF, 0xA0, learning_requests[0], learning_requests[1]]
            consecutive_frame = [0x21, learning_requests[2], learning_requests[3], learning_requests[4], 0x00, 0x00, 0x00, 0x00]# changed from 0x00 to 0xFF → to be tested

            data_packets = [
                {"message_id": self.UDS_SENDING_ID, "data": first_frame},
                {"message_id": self.UDS_SENDING_ID, "data": consecutive_frame}
            ]

            self.logger.info(f"Prepared learning request for motor {motor_name} on ECU {ecu_id}")
            return data_packets

        except Exception as e:
            self.logger.error(f"Error preparing learning request for {motor_name}: {e}")
            return None

    def _prepare_motor_command(self, motor_name: str, value: int, signal_type: str, mux_key: str) -> Optional[Dict[str, Any]]:
        """
        Build a complete CAN payload for one motor command.
        Uses mux_byte for CMDBYTE1 instead of CMDBYTE21.
        """
        try:
            # --- 1. Validate DBC + signal presence ----------------------------------------
            db = self.motors_dbs.get(motor_name)
            if not db:
                self.logger.error(f"No DBC loaded for motor '{motor_name}'.")
                return None

            signal_name = getattr(self, signal_type).get(motor_name)
            if not signal_name:
                self.logger.error(f"No signal found for motor '{motor_name}' and type '{signal_type}'.")
                return None

            ecu_id = self._get_ecu_id_by_motor(motor_name)
            mux_byte = self.mux_bytes_per_ecu[ecu_id].get(mux_key)
            
            if mux_byte is None:
                self.logger.error(f"No mux_byte found for mux_key '{mux_key}' in ECU {ecu_id}")
                return None

            msg_obj = db.get_message_by_name(self.SEAT_COMMANDS_ALL)
            
            # Get valid multiplexer values for CMDBYTE1
            cmdbyte1_signal = next((sig for sig in msg_obj.signals if sig.name == "CMDBYTE1"), None)
            if cmdbyte1_signal and hasattr(cmdbyte1_signal, 'choices'):
                valid_values = list(cmdbyte1_signal.choices.keys()) if cmdbyte1_signal.choices else []
                if valid_values and mux_byte not in valid_values:
                    self.logger.error(
                        f"Invalid mux_byte {mux_byte} for motor '{motor_name}' and mux_key '{mux_key}'. "
                        f"Valid values: {valid_values}"
                    )
                    return None

            # --- 2. Filter valid signals for this mux byte --------------------------------
            valid_signals = {
                sig.name: sig
                for sig in msg_obj.signals
                if sig.multiplexer_signal is None or mux_byte in sig.multiplexer_ids
            }
            if not valid_signals:
                self.logger.error(f"No valid signals for motor '{motor_name}' with mux {mux_byte}.")
                return None

            # Reverse map: signal → motor name (for known motors)
            sig_to_motor = {sig: mot for mot, sig in getattr(self, signal_type).items()}

            # --- 3. Build payload with defaults -------------------------------------------
            signal_dict = {}

            for sig in valid_signals:
                if sig == signal_name:
                    continue  # we'll add this explicitly later

                if sig in sig_to_motor:
                    mot = sig_to_motor[sig]
                    # Use cached last-requested values per signal type
                    if signal_type == "position_signals":
                        curr = self.last_requested_positions.get(mot, 102)
                    elif signal_type == "speed_signals":
                        curr = self.last_requested_speeds.get(mot, 0)
                    else:
                        curr = 0
                    signal_dict[sig] = curr
                else:
                    signal_dict[sig] = 0

            # --- 4. Set the requested signal value ----------------------------------------
            signal_dict[signal_name] = value

            # --- 5. Set CMDBYTE1 to the mux_byte value ------------------------------------
            signal_dict["CMDBYTE1"] = mux_byte

            #self.logger.info(f"Prepared signal dict for {motor_name}: {signal_dict}")

            return {
                "ecu_id": ecu_id,
                "message_name": self.SEAT_COMMANDS_ALL,
                "signal_dict": signal_dict,
                "motor_name": motor_name,
                "signal_name": signal_name,
                "value": value
            }

        except Exception as e:
            self.logger.error(f"Error preparing motor command for {motor_name}: {e}")
            return None

    def process_can_message(self, arbitration_id: int, message_data: bytes) -> Optional[Dict[str, Any]]:
        """
        Process incoming CAN message and return decoded data.

        Returns:
            Dictionary with processed message data or None if message should be ignored
        """
        try:
            # Retrieve the ECU number from the arbitration map
            ecu_num = self.ecu_arbitration_map.get(arbitration_id)
            if ecu_num is None:
                return None

            db = self.dbc_loader.dbs.get(ecu_num)
            if not db:
                self.logger.error(f"No DBC loaded for ECU {ecu_num}.")
                return None

            # Decode the message
            decoded = db.decode_message(arbitration_id, message_data)

            # Check if the message corresponds to SEAT_STATUS_STC
            if arbitration_id == self._get_msg_id(ecu_num, self.SEAT_STATUS_STC):
                return self._handle_decoded_message(ecu_num, decoded)
            else:
                return None

        except Exception as e:
            self.logger.error(f"Error processing CAN message: {e}")
            return None

    def _handle_decoded_message(self, ecu_num: int, decoded_message: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Handle decoded CAN signals and return motor updates."""
        # Extract CMDBYTE1 (now used as mux byte) from the decoded message
        cmd_byte1 = decoded_message.get("CMDBYTE1")
        if cmd_byte1 is None:
            self.logger.warning(f"CMDBYTE1 (mux byte) not found in message from ECU {ecu_num}")
            return None

        # Retrieve the mux bytes for the ECU
        mux_bytes = self.mux_bytes_per_ecu.get(ecu_num, {})
        if not mux_bytes:
            self.logger.warning(f"No mux bytes found for ECU {ecu_num}")
            return None

        # Process messages based on the value of CMDBYTE1
        if cmd_byte1 == mux_bytes.get("seat_position_information"):
            return self._process_motor_updates(decoded_message, self.percentage_status_signals,
                                               self.motor_positions, "Percentage")
        elif cmd_byte1 == mux_bytes.get("seat_speed_information"):
            return self._process_motor_updates(decoded_message, self.speed_status_signals,
                                               self.motor_speeds, "Speed_Percentage")
        else:
            return None

    def _process_motor_updates(self, decoded_message: Dict[str, Any], signal_map: Dict[str, str],
                            current_map: Dict[str, Any], data_type: str) -> Optional[Dict[str, Any]]:
        """Process signals and return motor update information."""
        motor_updates = {}

        for signal, value in decoded_message.items():
            motor_name = next(
                (motor for motor, signal_name in signal_map.items() if signal_name == signal),
                None
            )

            if not motor_name:
                continue

            # ADD: Thread-safe state update
            with self._state_lock:
                if motor_name in current_map and current_map[motor_name] == value:
                    continue

                current_map[motor_name] = value
                motor_updates[motor_name] = {"type": data_type, "value": value}

            self.logger.info(f"Motor {motor_name} {data_type} updated to {value}")

        return motor_updates if motor_updates else None

    def get_message_info(self, ecu_id: int, message_name: str) -> Optional[Dict[str, Any]]:
        """Get message information for CAN message preparation."""
        try:
            msg_id = self._get_msg_id(ecu_id, message_name)
            db = self.dbc_loader.dbs.get(ecu_id)
            if not db:
                return None

            return {
                "msg_id": msg_id,
                "db": db
            }
        except Exception as e:
            self.logger.error(f"Error getting message info: {e}")
            return None

    def _get_ecu_id_by_motor(self, motor_name: str) -> int:
        """Retrieve the ECU ID for a given motor."""
        for ecu in self.ecus:
            ecu_id = ecu.get("id")
            motors = ecu.get("motors", [])
            if motor_name in motors:
                return ecu_id
        raise ValueError(f"Motor '{motor_name}' not found in any ECU configuration.")

    def _get_msg_id(self, ecu_id: int, key: str) -> int:
        """Get message ID from DBC loader."""
        msg_id = self.dbc_loader.get_message_ids(ecu_id).get(key)
        return msg_id
    
    def has_reached_requested_position(self, motor_name: str, tolerance: int = 1) -> Optional[bool]:

        requested = self.last_requested_positions.get(motor_name)
        actual = self.motor_positions.get(motor_name)
        if requested is None or actual is None:
            self.logger.warning(f"Requested or actual position not available for motor '{motor_name}'")
            return None
        # If already at the requested position, treat as reached immediately
        if requested == actual:
            self.logger.info(f"Motor '{motor_name}' is already at the requested position {requested}. Position reached immediately.")
            return True
        
        reached = abs(requested - actual) <= tolerance
        self.logger.info(f"Motor '{motor_name}': requested={requested}, actual={actual}, reached={reached}")
        return reached
    
    # Public methods for getting motor status
    def get_motor_position(self, motor_name: str) -> Optional[int]:
        """Get current position of a motor (thread-safe)."""
        with self._state_lock:
            return self.motor_positions.get(motor_name)

    def get_motor_speed(self, motor_name: str) -> Optional[int]:
        """Get current speed of a motor (thread-safe)."""
        with self._state_lock:
            return self.motor_speeds.get(motor_name)

    def get_all_motor_positions(self) -> Dict[str, int]:
        """Get all motor positions (thread-safe)."""
        with self._state_lock:
            return self.motor_positions.copy()

    def get_all_motor_speeds(self) -> Dict[str, int]:
        """Get all motor speeds (thread-safe)."""
        with self._state_lock:
            return self.motor_speeds.copy()

    def get_ecu_arbitration_map(self) -> Dict[int, int]:
        """Get the ECU arbitration mapping."""
        return self.ecu_arbitration_map.copy()

    def enter_extended_session(self):
        """Return CAN ID and data bytes for entering extended session"""
        return self.UDS_SENDING_ID, [0x02, 0x10, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00]

    def exit_extended_session(self) :
        """Return CAN ID and data bytes for exiting extended session (default session)"""
        return self.UDS_SENDING_ID, [0x02, 0x10, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00]

    def check_learning_status(self) :
        return self.UDS_SENDING_ID, [0x03, 0x22, 0xF0, 0x54, 0x00, 0x00, 0x00, 0x00]

    def check_software_version(self):
        return self.UDS_SENDING_ID, [0x03, 0x22, 0xF1, 0x81, 0x00, 0x00, 0x00, 0x00]

    def get_motors(self) -> list:
        """Return a list of all motor names."""
        return list(self.motors)