from enum import Enum


class ScenarioState(Enum):
    WELCOME = "WELCOME"
    INITIAL = "INITIAL"
    MAIN = "MAIN"
    EXIT = "EXIT"
