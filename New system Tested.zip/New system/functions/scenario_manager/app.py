import time
import json
import logging
import threading
from typing import Optional

from functions.scenario_manager.state.scenario_state import ScenarioState
from functions.scenario_manager.data.scenario_flags import ScenarioFlags
from functions.scenario_manager.data.scenario_data import ScenarioData
from network.protocol_factory import ProtocolFactory


class ScenarioManager:
    def __init__(self, config: dict, protocol):

        # ---------------- LOGGING ----------------
        self.logger = logging.getLogger(f"{__name__}.{self.__class__.__name__}")
        self.logger.setLevel(logging.INFO)

        fh = logging.FileHandler("scenario_manager.log", encoding="utf-8")
        formatter = logging.Formatter(
            "%(asctime)s [%(threadName)s] %(levelname)s: %(message)s"
        )
        fh.setFormatter(formatter)
        self.logger.addHandler(fh)

        self.logger.info("Initializing ScenarioManager")

        # ---------------- CONFIG ----------------
        self.config = config
        protocol_cfg = config.get("protocol", {})
        self.scenario_cfg = config.get("scenario", {})
        self.tick_period = self.scenario_cfg.get("tick_period_ms", 50) / 1000.0

        self.sub_topics = protocol_cfg.get("sub_topics", {})
        self.pub_topics = protocol_cfg.get("pub_topics", {})

        # ---------------- STATE CONTAINERS (MOVE UP) ----------------
        self.flags = ScenarioFlags()
        self.data = ScenarioData()

        # ---------------- STATE ----------------
        self.current_state: ScenarioState = ScenarioState.WELCOME

        # ---------------- PROTOCOL ----------------
        self.mqtt = protocol
        self.mqtt.set_on_receive_callback(self._on_mqtt_message)
        self.mqtt.subscribe()   # ⬅️ subscribe AFTER flags exist

        self.aio_protocol = ProtocolFactory.create_instance(
            config.get('aio_protocol')
        )

        self._publish_state()

        # ---------------- THREAD ----------------
        self.stop_event = threading.Event()
        self.manager_thread = threading.Thread(
            target=self._manager_loop,
            daemon=True,
            name="ScenarioManagerLoop"
        )
        self.manager_thread.start()

        self.logger.info("ScenarioManager initialized and running")


    # ==================================================
    # MQTT CALLBACK
    def _on_mqtt_message(self, msg):
        topic = msg.topic
        payload = msg.payload.decode().strip()

        # -------- GLOBAL TOPICS --------
        if topic == self.sub_topics.get("welcome_position_request_sub"):
            self.logger.info("Welcome position requested from HMI")
            self.flags.set_welcome_requested(True)

        elif topic == self.sub_topics.get("custom_motor_position_reached_sub"):
            self.logger.info(f"Motor position reached: {payload}")
            if payload.lower() == "welcome":
                self.flags.set_welcome_position_reached(True)

        elif topic == self.sub_topics.get("human_detection_sub"):
            detected = payload == "1"
            self.flags.set_human_detected(detected)
            if detected :
                self._publish(self.pub_topics.get("welcome_animation_command"), "1")
                self.logger.info(f"Human detected: {detected}")
            else :
                self.logger.info(f"Human Not detected: {detected}")

        elif topic == self.sub_topics.get("calibrate_aio_sub"):
            self.logger.info("Calibration requested")
            self.trigger_calibration_done()

        elif topic == self.sub_topics.get("initial_adaptation_request_sub"):
            self.logger.info("Initial adaptation requested")
            self.flags.set_initial_adaptation_requested(True)

        elif topic == self.sub_topics.get("main_done_sub"):
            self.logger.info("Main phase done")
            self.flags.set_main_done(True)

        elif topic == self.sub_topics.get("exit_sub"):
            self.logger.info("Exit requested")
            self.flags.set_exit_requested(True)
        elif topic == self.sub_topics.get("user_record_start_hmi_sub"):
            self.logger.info("User Record start")
            self._publish(self.pub_topics.get("user_record_start_pub"), "1")
        
        elif topic == self.sub_topics.get("user_recognition_sub"):
            self.logger.info(f"User ID : {payload}")
            self._publish(self.pub_topics.get("user_id_pub"), payload)

        elif topic == self.sub_topics.get("reset_sub"):
            self.logger.info("Reset requested")
            self._publish(self.pub_topics.get("reset_pub"), "1")
            self.reset()
        elif topic == self.sub_topics.get("welcome_pneumatic_animation_done"):
            self.flags.set_welcome_animation_done(True)
        elif topic in (
            self.sub_topics.get("track_sub"),
            self.sub_topics.get("backrest_sub"),
            self.sub_topics.get("cla_sub"),
            self.sub_topics.get("height_sub"),
            self.sub_topics.get("tilt_sub"),
        ):
            self._handle_sm_direction(topic, payload)

        # -------- MAIN-ONLY TOPICS --------
        elif self._is_main():
            if topic == self.sub_topics.get("followme_request_sub"):
                self._publish(self.pub_topics.get("mode_switch_pub"), "FollowMe")

            elif topic == self.sub_topics.get("sport_position_request_sub"):
                self._publish(self.pub_topics.get("sport_position_request_motors_pub"), "1")
                self._publish(self.pub_topics.get("mode_switch_pub"), "ShapeFit")
                self._publish(self.pub_topics.get("driving_mode_pub"), "Sport")

            elif topic == self.sub_topics.get("comfort_position_request_sub"):
                self._publish(self.pub_topics.get("comfort_position_request_motors_pub"), "1")
                self._publish(self.pub_topics.get("mode_switch_pub"), "ShapeFit")
                self._publish(self.pub_topics.get("driving_mode_pub"), "Comfort")

            elif topic == self.sub_topics.get("zerog_position_request_sub"):
                self._publish(self.pub_topics.get("zerog_position_request_motors_pub"), "1")
                self._publish(self.pub_topics.get("mode_switch_pub"), "ShapeFit")
                self._publish(self.pub_topics.get("driving_mode_pub"), "ZeroG")

            elif topic == self.sub_topics.get("fatigue_relief_sub"):
                self._publish(self.pub_topics.get("pneumatic_fatigue_relief_start"), "1")
            elif topic == self.sub_topics.get("magic_carpet_sub") :
                self._publish(self.pub_topics.get("magic_carpet_start_pub"), payload)
            elif topic == self.sub_topics.get("turning_sub"):
                self._publish(self.pub_topics.get("mode_switch_pub"), "DynamicBolster")

            elif topic == self.sub_topics.get("acceleration_sub"):
                self._publish(self.pub_topics.get("mode_switch_pub"), "Acceleration")

    # ==================================================
    # MANAGER LOOP
    # ==================================================
    def _manager_loop(self):
        while not self.stop_event.is_set():
            start = time.time()
            self._update_state_machine()
            time.sleep(max(0.0, self.tick_period - (time.time() - start)))

    # ==================================================
    # STATE MACHINE
    # ==================================================
    def _update_state_machine(self):
        if self.flags.get_exit_requested():
            self._transition_to(ScenarioState.EXIT)
            return

        if self.current_state == ScenarioState.WELCOME:
            self._execute_welcome_actions()

            if (
                self.flags.get_initial_adaptation_requested()
                and self.flags.get_welcome_animation_done()
                and not self.flags.get_initial_adaptation_started()
            ):
                self._transition_to(ScenarioState.INITIAL)

        elif self.current_state == ScenarioState.INITIAL:
            if not self.flags.get_initial_adaptation_started():
                self.flags.set_initial_adaptation_started(True)
                self._execute_initial_adaptation_actions()

            if self.flags.get_initial_adaptation_done():
                self._transition_to(ScenarioState.MAIN)

        elif self.current_state == ScenarioState.MAIN:
            if self.flags.get_main_done():
                self._transition_to(ScenarioState.EXIT)

    # ==================================================
    # STATE TRANSITIONS
    # ==================================================
    def _transition_to(self, next_state: ScenarioState):
        if self.current_state == next_state:
            return

        prev = self.current_state
        self.current_state = next_state

        self.logger.info(f"STATE {prev.value} -> {next_state.value}")
        self._publish_transition(prev.value, next_state.value)
        self._publish_state()
        self._on_enter_state(next_state)

    def _on_enter_state(self, state: ScenarioState):
        if state == ScenarioState.MAIN:
            self._publish(self.pub_topics.get("main_start_pub"), "1")

        elif state == ScenarioState.EXIT:
            self._publish(self.pub_topics.get("exit_pub"), "1")
            self._publish(self.pub_topics.get("lumbar_reset"), "Rear")

    def _map_direction(self, payload: str) -> Optional[str]:
        value = payload.strip().lower()

        if value in ("forward", "up"):
            return "1"
        elif value in ("rear", "down","backward"):
            return "2"
        elif value == "stop":
            return "0"

        return None

    def _handle_sm_direction(self, topic: str, payload: str):
        mapped_value = self._map_direction(payload)

        if mapped_value is None:
            self.logger.warning(f"Unknown direction payload '{payload}' on {topic}")
            return

        # Convert Seat/SM/... → SM/MSM/...
        target_topic = topic.replace("Seat/SM/", "SM/MSM/")

        self.logger.info(
            f"Direction command: {topic} [{payload}] → {target_topic} [{mapped_value}]"
        )

        self._publish(target_topic, mapped_value)
    # ACTIONS
    def _execute_welcome_actions(self):
        if self.flags.get_welcome_requested():
            self._publish(self.pub_topics.get("welcome_position_request_motors_pub"), "1")
            self.flags.set_welcome_requested(False)

        if (
            self.flags.get_welcome_position_reached()
            and not self.flags.get_calibration_done()
        ):
            self.trigger_calibration_done()

        #if (
        #    self.flags.get_welcome_position_reached()
        #    and self.flags.get_human_detected()
        #    and not self.flags.get_welcome_animation_done()
        #):

    def _execute_initial_adaptation_actions(self):
        self._publish(self.pub_topics.get("mode_switch_pub"), "ShapeFit")
        self._publish(self.pub_topics.get("driving_mode_pub"), "InitialAdaptation")
        self.flags.set_initial_adaptation_done(True)

    # HELPERS
    def _publish_state(self):
        self._publish(self.pub_topics.get("state_pub"), self.current_state.value)

    def _publish_transition(self, src, dst):
        self._publish(
            self.pub_topics.get("transition_pub"),
            json.dumps({"from": src, "to": dst, "timestamp": time.time()})
        )

    def _publish(self, topic: Optional[str], payload: str):
        if topic:
            try:
                self.mqtt.send(topic, payload, 1, False)
            except Exception as e:
                self.logger.error(f"Publish failed {topic}: {e}")

    def trigger_calibration_done(self):
        self.logger.info("Calibration completed")
        self.aio_protocol.send(json.dumps({"calibrate": "1"}))
        time.sleep(0.5)
        self.flags.set_calibration_done(True)

    def _is_main(self) -> bool:
        return self.current_state == ScenarioState.MAIN

    # RESET / SHUTDOWN
    def reset(self):
        self.flags.reset()
        self.data.reset()
        self._transition_to(ScenarioState.WELCOME)

    def on_exit(self):
        self.stop_event.set()
        self.manager_thread.join(timeout=1.0)
        if self.mqtt:
            self.mqtt.disconnect()
