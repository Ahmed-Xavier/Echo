class ScenarioData:
    def __init__(self):
        self.current_value = 0
        self.target_value = 100
        self.mode = "IDLE"

    # ---------------- GETTERS ----------------
    def get_current_value(self):
        return self.current_value

    def get_target_value(self):
        return self.target_value

    def get_mode(self):
        return self.mode

    # ---------------- SETTERS ----------------
    def set_current_value(self, val):
        self.current_value = val

    def set_target_value(self, val):
        self.target_value = val

    def set_mode(self, val):
        self.mode = val

    # ---------------- RESET ----------------
    def reset(self):
        self.current_value = 0
        self.target_value = 100
        self.mode = "IDLE"
