class ScenarioFlags:
    def __init__(self):
        # ---------------- WELCOME PHASE FLAGS ----------------
        self.welcome_requested = False
        self.welcome_position_reached = False
        self.calibration_done = False
        self.welcome_animation_done = False

        # ---------------- INITIAL ADAPTATION PHASE FLAGS ----------------
        self.initial_adaptation_requested = False
        self.initial_adaptation_started = False
        self.initial_adaptation_done = False
        self.human_detected = False

        # ---------------- MAIN PHASE FLAGS ----------------
        self.main_done = False

        # ---------------- EXIT PHASE FLAGS ----------------
        self.exit_requested = False

    # ==================================================
    # WELCOME PHASE GETTERS
    # ==================================================
    def get_welcome_requested(self):
        return self.welcome_requested

    def get_welcome_position_reached(self):
        return self.welcome_position_reached

    def get_calibration_done(self):
        return self.calibration_done

    def get_welcome_animation_done(self):
        return self.welcome_animation_done

    # ==================================================
    # INITIAL ADAPTATION PHASE GETTERS
    # ==================================================
    def get_initial_adaptation_requested(self):
        return self.initial_adaptation_requested

    def get_initial_adaptation_started(self):
        return self.initial_adaptation_started

    def get_initial_adaptation_done(self):
        return self.initial_adaptation_done

    def get_human_detected(self):
        return self.human_detected

    # ==================================================
    # MAIN PHASE GETTERS
    # ==================================================
    def get_main_done(self):
        return self.main_done

    # ==================================================
    # EXIT PHASE GETTERS
    # ==================================================
    def get_exit_requested(self):
        return self.exit_requested

    # ==================================================
    # WELCOME PHASE SETTERS
    # ==================================================
    def set_welcome_requested(self, value: bool):
        self.welcome_requested = value

    def set_welcome_position_reached(self, value: bool):
        self.welcome_position_reached = value

    def set_calibration_done(self, value: bool):
        self.calibration_done = value

    def set_welcome_animation_done(self, value: bool):
        self.welcome_animation_done = value

    # ==================================================
    # INITIAL ADAPTATION PHASE SETTERS
    # ==================================================
    def set_initial_adaptation_requested(self, value: bool):
        self.initial_adaptation_requested = value

    def set_initial_adaptation_started(self, value: bool):
        self.initial_adaptation_started = value

    def set_initial_adaptation_done(self, value: bool):
        self.initial_adaptation_done = value

    def set_human_detected(self, value: bool):
        self.human_detected = value

    # ==================================================
    # MAIN PHASE SETTERS
    # ==================================================
    def set_main_done(self, value: bool):
        self.main_done = value

    # ==================================================
    # EXIT PHASE SETTERS
    # ==================================================
    def set_exit_requested(self, value: bool):
        self.exit_requested = value

    # ==================================================
    # RESET
    # ==================================================
    def reset(self):
        # Welcome phase
        self.welcome_requested = False
        self.welcome_position_reached = False
        self.calibration_done = False
        self.welcome_animation_done = False

        # Initial adaptation phase
        self.initial_adaptation_requested = False
        self.initial_adaptation_started = False
        self.initial_adaptation_done = False
        self.human_detected = False

        # Main phase
        self.main_done = False

        # Exit phase
        self.exit_requested = False
