import time
import paho.mqtt.client as mqtt

BROKER_IP = "192.168.55.206"
BROKER_PORT = 1883

TOPICS = {
    "1": ("WELCOME request", "HMI/SM/CustomPositionReq/Welcome", "1"),
    "2": ("Motor reached = welcome", "Motors/SM/Position/Reached", "welcome"),
    "3": ("Human detected", "Seat/SM/DataFusion/ODS/Occupant/Detected", "1"),
    "4": ("Initial adaptation request", "HMI/SM/InitialAdaptation", "1"),
    "5": ("Main done", "HMI/SM/Main/Done", "1"),
    "6": ("Exit", "HMI/SM/Exit", "1"),
    "7": ("Reset", "HMI/SM/RestartDemo", "1"),
}

def on_connect(client, userdata, flags, rc):
    print("✅ Connected to MQTT broker")

client = mqtt.Client()
client.on_connect = on_connect
client.connect(BROKER_IP, BROKER_PORT, 60)
client.loop_start()

def send(key):
    label, topic, payload = TOPICS[key]
    print(f"→ {label}")
    print(f"  topic   = {topic}")
    print(f"  payload = {payload}")
    client.publish(topic, payload, qos=1, retain=True)

print("\n=== Scenario Manual Sender ===")
print("Press a key to send ONE message:\n")

for k, v in TOPICS.items():
    print(f" {k}. {v[0]}")

print("\n q. Quit\n")

try:
    while True:
        key = input("Select message > ").strip()
        if key == "q":
            break
        if key in TOPICS:
            send(key)
        else:
            print("❌ Invalid choice")

except KeyboardInterrupt:
    pass
finally:
    client.loop_stop()
    client.disconnect()
    print("Disconnected")
