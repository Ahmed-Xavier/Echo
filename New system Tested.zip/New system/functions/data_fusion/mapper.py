from abc import ABC, abstractmethod
from typing import Any, Callable
import logging


class Mapper(ABC):

    def __init__(self, standardized_data:dict, path_to_in_data_structure: str):
        # TODO associate the function name to the logger !
        self.function = conf.get('function')
        self.host = conf.get('host')
        self.port = conf.get('port')
        self.retry_s = conf.get('retry_connection_s')
        self.__on_receive = lambda data: data  # Do nothing

    @abstractmethod
    def read_in_data_structure(self, data: Any):
        pass

    @abstractmethod
    def map_data(self, data):
        pass
