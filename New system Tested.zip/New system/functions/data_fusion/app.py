import os
import logging
import json
import time
import threading
from network.protocol_factory import ProtocolFactory
from functions.data_fusion.mapper_factory import MapperFactory
import pandas as pd


class DataFusion:
    HEIGHT_NONE                     = 0
    MIN_AIO_OOP_PREDICTION_COUNT    = 8
    UNSAFE                          = 1
    SAFE                            = 0
    MIN_CAMERA_OOP_PREDICTION_COUNT = 12
    ODS_PREDICTION_COUNT_MAX        = 30 # 3 * 0.1s (sampling time of AIO) ==> 3s stability time

    POSSIBLE_SIZES = ['S', 'M', 'L']
    def __init__(self, config, protocol=None):
        self.camera_data = None
        self.is_ready = False
        os.chdir(os.path.abspath(os.path.dirname(__file__)))
        super().__init__()
        self.logger = logging.getLogger(f'{__name__}_{__class__.__name__}')
        self.config = config
        self.protocol = protocol
        self.activated_ods = config.get('activate_ods')
        self.activated_oop = config.get('activate_oop')
        self.activated_safety = config.get('activate_safety')
        self.activated_ocs   = config.get('activate_ocs')

        self.driving_modes = self.config.get('driving_modes')
        self.driving_mode = self.driving_modes.get('driving')

        
        # MQTT Config
        self.sub_topics = self.config.get('protocol').get('sub_topics')
        self.pub_topics = self.config.get('protocol').get('pub_topics')
        self.protocol.subscribe()
        self.protocol.set_on_receive_callback(self.mqtt_on_message)
        ### *****************OOP VARIABLES ********************************
        self.aio_protocol = ProtocolFactory.create_instance(config.get('aio_protocol'))
        self.aio_prediction_count = 0
        self.prediction = ''
        self.prev_prediction = ''
        self.prediction_sent = ''
        self.prev_ods_predicted = 0
        self.ods_predicted = 0
        # oop aio
        self.oop_aio = 'GoodPosture'
        self.current_oop_aio = 'GoodPosture'
        self.prev_oop_aio = ''
        self.prediction_sent = ''
        # get AIO interface configs
        

        self.aio_protocol.set_on_receive_callback(self.on_aio_receive)
        self.aio_data = None #{'offset': [0] * 10}
        self.seat_belt = False
        self.prev_seat_belt = None
        ###************* ODS & OOP *********************************
        self.sizes = {
            'S':  0,
            'M': 1,
            'L': 2
        }
        self.seat_position = 1
        self.sensor_data_dict = None
        self.ods_prediction_count = 0 
        self.aio_oops = {
            0 : 'GoodPosture', 
            1 : 'LeaningForward',
            2 : 'PelvisDrift'
        }
        

        ###*****************CAMERA  VARIABLES ********************************
        # used for height 
        self.camera_prediction = ''
        self.camera_prev_prediction = ''
        self.is_height_estimated = False
        # used for oops 
        self.current_oop_camera = 0
        self.oop_camera = 0
        self.oop_camera_counter = 0 
        self.oop_camera_result = 0

        # Classes Config
        self.human_classes = self.config.get('human_classes')
        self.height_classes = self.config.get('height_classes')
        self.weight_classes = self.config.get('weight_classes')
        self.age_classes    = self.config.get('age_classes')
        self.sex_classes    = self.config.get('sex_classes')
        self.camera_oop_classes    = self.config.get('camera_oop')
        # get camera interface configs
        self.camera_protocol = ProtocolFactory.create_instance(config.get('camera_protocol'))
        self.camera_protocol.set_on_receive_callback(self.on_camera_receive)

        # Handle gloabla oops
        self.oop = 'GoodPosture'
        self.prev_oop  = '' 

        # safety variables
        self.safety_status = DataFusion.SAFE
        self.prev_safety_status = DataFusion.SAFE

        ###########hip class
        self.human_class_sent = False
        self.current_human_class = ''
        self.human_class = ''
        self.ocs_human_class_counter = 0
        ###############  Fusion thread loop 
        self.thread = threading.Thread(target=self.handle_data_fusion)
        self.stop_recv_event = threading.Event()
        self.thread.start()
        self.is_ready = True
        
    ####################################################################################################################


    def handle_data_fusion(self) :
        #ACTIVATE AND DEACTIVATE ANY SERVICE YOU WANT
        self.logger.debug(f"activated ods{self.activated_ods}")
        while not self.stop_recv_event.is_set() :
            if self.activated_ods:
             self.handle_ods_events()
            if self.activated_oop:
             self.handle_oop_events()
            if self.activated_safety:
             self.handle_safety_events()
            if self.activated_ocs:
             self.handle_ocs_events()
            time.sleep(0.06)


    def mqtt_on_message(self, message):
        self.logger.debug(f"{message.topic}: {message.payload.decode()}")
        if message.topic == self.sub_topics["driving_mode_sub"]:
            _message_driving_mode = message.payload.decode().strip().lower()
            if _message_driving_mode in self.driving_modes:
                self.driving_mode = self.driving_modes[_message_driving_mode]
                self.logger.info(f"Updated driving mode: {self.driving_mode}")
            else:
                self.logger.debug(f"Ignored invalid driving mode: {_message_driving_mode}")
        if message.topic == self.sub_topics["reset_sub"]:
            self.reset()
        if message.topic == self.sub_topics["seat_belt_sub"]:
            self.seat_belt = True if message.payload.decode() == "1" else False
            print(self.seat_belt)
        if message.topic == self.sub_topics["override_height_estimation_sub"]:
            payload = message.payload.decode()
            if payload in DataFusion.POSSIBLE_SIZES:
                 self.camera_prediction = payload
                 self.seat_position = self.sizes.get(payload)
                 self.is_height_estimated = True
        if message.topic == self.sub_topics.get("check_is_ready_sub"):
            # immediate response (safe_send is non-blocking/guarded)
            self.check_is_ready()


    def check_is_ready(self):
        """Publish readiness state via protocol if ready."""
        if self.is_ready:
            self.protocol.send(self.pub_topics.get("is_ready_pub"), self.__class__.__name__, 2, False)
    ####################################################################################################################


    def on_camera_receive(self, data):
        try:
            self.camera_data = json.loads(data)
            #self.logger.info(f"Camera data received: {self.camera_data}")
        except Exception as e:
            self.logger.error(f"Error parsing Camera data: {data}, error: {e}")


    ####################################################################################################################
    def on_aio_receive(self, data):
        try:
            # Split the data by newlines and process each line separately
            lines = data.strip().split('\n')
            
            for line in lines:
                line = line.strip()
                if line:  # Skip empty lines
                    try:
                        parsed_data = json.loads(line)
                        # Use the most recent valid JSON object
                        self.aio_data = parsed_data
                        self.logger.info(f"AIO Data Received: {self.aio_data}")
                    except json.JSONDecodeError as line_error:
                        print(f"Error parsing individual line: {line}, error: {line_error}")
                        continue
                        
        except Exception as e:
            print(f"Error processing AIO data: {data}, error: {e}")

    def __process_aio_ods(self): 
        if self.aio_data :
            # CDP FRANCE OBJECT HUMAN 2 
            self.ods_predicted = 1 if int(self.aio_data.get('object_human')) == 1  else 0
            if self.prev_ods_predicted != self.ods_predicted:
                self.logger.info(f"ODS Prediction: {self.ods_predicted}")
                self.protocol.send(self.pub_topics.get("occupant_detected_pub"), self.ods_predicted, 2, False)
                self.prev_ods_predicted = self.ods_predicted


    def __process_aio_oop(self):
        if self.aio_data: 
            self.current_oop_aio = 'PelvisDrift' if int(self.aio_data.get('pelvis_alarm')) == 1 else 'GoodPosture'
            if self.prev_oop_aio == self.current_oop_aio:
                self.aio_prediction_count += 1
                if self.aio_prediction_count == DataFusion.MIN_AIO_OOP_PREDICTION_COUNT: #and self.prediction_sent != self.prediction:
                    self.oop_aio = self.current_oop_aio
                    self.logger.info(f"New predicted Postural position: {self.oop_aio}")
                    print(f"New predicted Postural position ------------------> : {self.oop_aio}")
            else:
                self.aio_prediction_count = 0
                self.prev_oop_aio = self.current_oop_aio



    def handle_oop_events(self) : 
        if self.ods_predicted == 1:
            if self.aio_data is not None :
                #self.__process_aio_oop()
                #self.__process_aio_oop_model()
                pass
            if self.camera_data is not None :
                self.current_oop_camera = self.camera_data.get('out-of-position').get('out-of-position-class')
                #self.logger.info(f"Camera OOP: {self.current_oop_camera}")

                #print(self.current_oop_camera)
                if self.current_oop_camera == self.oop_camera : 
                    self.oop_camera_counter += 1
                    if  self.oop_camera_counter == DataFusion.MIN_CAMERA_OOP_PREDICTION_COUNT: 
                        self.oop_camera_result = self.current_oop_camera  
                else : 
                    self.oop_camera_counter = 0 
                    self.oop_camera =  self.current_oop_camera 
            # handle priority on OOP 
            if self.camera_oop_classes.get(self.oop_camera_result) in ["ReachingRearBench", "ReachingGloveBox", "LeanOut"] : 
                self.oop = self.camera_oop_classes.get(self.oop_camera_result) # Reaching GloveBox, Reaching Rearbench
            else : 
                self.oop = self.oop_aio 
            # check if oop changed compared to last oop detected 
            if  self.prev_oop != self.oop : 
                self.protocol.send(self.pub_topics.get("is_oop_class_pub"), self.oop, 2, False)
                self.prev_oop = self.oop  
                self.logger.info(f"current oop ============================>>{self.oop}")

    def handle_safety_events(self) : 
        # Se to Safe when the persoon quit the seat
        if self.ods_predicted == 0:
            self.safety_status  = DataFusion.SAFE
        if self.ods_predicted == 1:  # detcted
            # UNSAFE IF SEAT BELT IS NOT ON (SEND ONLY AT CHANGE)
            if (self.oop != "Other" and  self.oop != "GoodPosture") or self.seat_belt == False: 
                self.safety_status  = DataFusion.UNSAFE                
            else : 
                self.safety_status  = DataFusion.SAFE
            print(f'check safety status  ------------> {self.safety_status} oop = {self.oop}, seat-belt= {self.seat_belt}' )
            if self.prev_safety_status != self.safety_status:  
                self.protocol.send(self.pub_topics.get("safety_status_pub"), self.safety_status, 2, False)
                print('safety --> ',self.safety_status )
                self.prev_safety_status = self.safety_status

    def handle_ods_events(self):
        self.__process_aio_ods()

    def handle_ocs_events(self):
        # ---- HIP CLASS ----
        if self.aio_data is not None and self.ods_predicted == 1 and not self.human_class_sent:
            self.current_human_class = self.aio_data.get('human_class')
            if self.current_human_class == self.human_class:
                self.ocs_human_class_counter += 1
                if self.ocs_human_class_counter == DataFusion.MIN_CAMERA_OOP_PREDICTION_COUNT:
                    self.logger.info(f"human_class sent {self.current_human_class}")
                    self.protocol.send(self.pub_topics.get("occupant_class_pub"), self.current_human_class, 2, False)
                    self.human_class_sent = True
            else:
                self.ocs_human_class_counter = 0
                self.human_class = self.current_human_class

        # ---- HEIGHT CLASSIFICATION ----
        if self.camera_data is not None and self.ods_predicted == 1 and not self.is_height_estimated :
            height_info = self.camera_data.get('height', {})
            height_id = height_info.get('id')
            collecting = height_info.get('collecting', 1)

            if height_id is not None and collecting == 0:
                if height_id > 3:
                    height_id = 3  # cap to L
                height_class = self.height_classes.get(height_id)
                if height_class:
                    self.logger.info(f"Detected height class: {height_class}")
                    print(f"Detected height class: {height_class}")
                    self.protocol.send(self.pub_topics.get("occupant_height_class_pub"), height_class, 2, False)
                    self.is_height_estimated = True
                    self.camera_prev_prediction = height_id
                    self.seat_position = height_id - 1

    




               ####################################################################################################################

    
    def on_exit(self):
        self.protocol.disconnect()
        self.aio_protocol.disconnect()
        self.camera_protocol.disconnect()
        self.stop_recv_event.set()
        self.thread.join(timeout=2)

    def reset(self):
        self.logger.info("Resetting service DATA fusion to default...")
        self.aio_prediction_count = 0
        # oop from aio 
        self.oop_aio = ''
        self.current_oop_aio = ''
        self.prev_oop_aio = ''
        self.prediction_sent = ''
        self.prev_ods_predicted = ''
        self.ods_predicted = ''
        # used for camera height estimation
        self.camera_prediction = ''
        self.camera_prev_prediction = ''
        self.is_height_estimated = False
        #OCS VARIABLES HIP CLASS
        self.human_class_sent = False
        self.current_human_class = ''
        self.human_class = ''
        self.ocs_human_class_counter = 0
        

        self.seat_belt = False
        self.prev_seat_belt = None
        # Handle gloabl oops
        self.oop = 'GoodPosture'
        self.prev_oop  = '' 
        # used for camera oops 
        self.current_oop_camera = 0
        self.oop_camera = 0
        self.oop_camera_counter = 0 
        self.oop_camera_result = 0

        # safety variables
        self.safety_status = DataFusion.SAFE
        self.prev_safety_status = DataFusion.SAFE

        self.seat_position = 1
        self.sensor_data_dict = None
        self.ods_prediction_count = 0
        self.driving_mode = 0
        self.driving_modes = self.config.get('driving_modes')
