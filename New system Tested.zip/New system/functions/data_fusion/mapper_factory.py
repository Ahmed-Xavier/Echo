from functions.data_fusion.camera.mapper import CameraMapper
from functions.data_fusion.oop_ml.mapper import OOP_MLMapper
from functions.data_fusion.aio_postural.mapper import AIOPosturalMapper


class MapperFactory:
    @staticmethod
    def create_instance(name, *args, **kwargs):
        if name == 'aio_postural':
            return AIOPosturalMapper(args, kwargs)
        elif name == 'oop_ml':
            return OOP_MLMapper(args, kwargs)
        elif name == 'camera':
            return CameraMapper(args, kwargs)
        else:
            raise NotImplementedError(f'Add implementation for {name} Mapper !')
