class AIOPosturalMapper:
    def __init__(self, standard_data, mappings, weights):
        self.standard_data = standard_data
        self.mappings = mappings
        self.weights = weights
        """ Extract only the keys that will be treated by the fusion which has a weight different from 0
            {'occupation': 'occupant_detection', 'distraction': 'distraction_alarm',...} """
        self.items_to_fuse = {k: self.mappings.get(k) for k, weight in self.weights.items() if weight != 0}

    def map_data(self, data):
        for k in self.items_to_fuse.keys():
            pass


if __name__ == "__main__":
    mapper = AIOPosturalMapper()
    print(mapper.map_data())
