
class CameraMapper:
    def __init__(self, standard_data, mappings, weights):
        self.standard_data = standard_data
        self.mappings = mappings
        self.weights = weights
        """ Extract only the keys that will be treated by the fusion which has a weight different from 0
            {'occupation': 'occupant_detection', 'distraction': 'distraction_alarm',...} """
        self.items_to_fuse = { k: self.mappings.get(k) for k, weight in self.weights.items() if weight != 0}

        self.oop_value_to_standard_data_key = {
            1 : "reaching_rear_bench_alarm",
            2 : "reaching_glove_box_alarm",
            3 : "dissymmetry_alarm",
        }

    def map_data(self, data):
        for k in self.items_to_fuse.keys():
            self.standard_data[self.items_to_fuse[k]] = data[k].get('id') * data[k].get('confidence')
        self.handle_oop_class(data)

    def handle_oop_class(self, data):
        if data['oop-class'].get('id') == 0:  # No OOP
            for alarm in self.oop_value_to_standard_data_key.values():
                self.standard_data[alarm] = 0
        else:
            oop_index = data.get('oop-class').get('id')
            confidence = data('oop-class').get('confidence')
            self.standard_data[self.oop_value_to_standard_data_key[oop_index]] = 1 * confidence


if __name__ == "__main__":
    mapper = CameraMapper()
    print(mapper.map_data())



