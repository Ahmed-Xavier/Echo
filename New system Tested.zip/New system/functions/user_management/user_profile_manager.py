import json
import os
import logging
from datetime import datetime


class UserProfileManager:
    """Manages user profiles including reading, writing, and matching users based on offset data"""
    
    VALID_SENSOR_INDICES = [9, 8, 7, 6, 15, 14, 13, 12, 11, 10]
    
    def __init__(self, max_users=3, similarity_threshold=0.8, tolerance_percentage=4, profiles_file='user_profiles.json'):
        self.logger = logging.getLogger(f'{__name__}_{__class__.__name__}')
        self.profiles_file = profiles_file
        self.max_users = max_users
        self.similarity_threshold = similarity_threshold  # e.g., 0.8 means 8 out of 10 sensors must match
        self.tolerance_percentage = tolerance_percentage  # e.g., 4 means 4% tolerance
        
        # Load existing profiles
        self.profiles = self._load_profiles()
        self.logger.info(f"UserProfileManager initialized with {len(self.profiles)} existing profiles")
    
    def _load_profiles(self):
        """Load user profiles from JSON file"""
        if os.path.exists(self.profiles_file):
            try:
                with open(self.profiles_file, 'r') as f:
                    profiles = json.load(f)
                self.logger.info(f"Loaded {len(profiles)} user profiles from {self.profiles_file}")
                return profiles
            except Exception as e:
                self.logger.error(f"Error loading profiles: {e}")
                return []
        else:
            self.logger.info(f"No existing profiles found. Starting fresh.")
            return []
    
    def _save_profiles(self):
        """Save user profiles to JSON file"""
        try:
            with open(self.profiles_file, 'w') as f:
                json.dump(self.profiles, f, indent=2)
            self.logger.info(f"Saved {len(self.profiles)} user profiles to {self.profiles_file}")
        except Exception as e:
            self.logger.error(f"Error saving profiles: {e}")
    
    def _filter_offset_data(self, offset):
        """Filter offset data to include only valid sensor indices"""
        try:
            return [offset[i] for i in self.VALID_SENSOR_INDICES if i < len(offset)]
        except Exception as e:
            self.logger.error(f"Error filtering offset data: {e}")
            return []
    
    def calculate_average_offset(self, offset_snapshots):
        if not offset_snapshots:
            return None
        
        num_sensors = len(offset_snapshots[0]['offset'])
        avg_offsets = []
        
        for sensor_idx in range(num_sensors):
            sensor_values = [snapshot['offset'][sensor_idx] for snapshot in offset_snapshots]
            if sensor_values:
                avg_value = sum(sensor_values) / len(sensor_values)
                avg_offsets.append(round(avg_value, 2))
        
        return avg_offsets
    
    def calculate_similarity(self, offset1, offset2):
        try:
            if len(offset1) != len(offset2):
                self.logger.error("Offset profiles have different lengths")
                return 0.0
            
            matching_sensors = 0
            total_sensors = len(offset1)
            
            for i in range(total_sensors):
                val1 = offset1[i]
                val2 = offset2[i]
                
                # Calculate the tolerance range (4% of the value)
                if val1 == 0:
                    # If the reference value is 0, check if val2 is also 0
                    if val2 == 0:
                        matching_sensors += 1
                else:
                    # Calculate percentage difference
                    tolerance = abs(val1 * self.tolerance_percentage / 100)
                    if abs(val1 - val2) <= tolerance:
                        matching_sensors += 1
            
            # Calculate the proportion of matching sensors
            similarity = matching_sensors / total_sensors
            return similarity
            
        except Exception as e:
            self.logger.error(f"Error calculating similarity: {e}")
            return 0.0
    
    def find_matching_user(self, offset_profile):
        best_match_id = None
        best_similarity = 0.0
        
        for profile in self.profiles:
            similarity = self.calculate_similarity(offset_profile, profile['offset_profile'])
            
            if similarity > best_similarity:
                best_similarity = similarity
                best_match_id = profile['user_id']
        
        # Check if similarity meets threshold
        if best_similarity >= self.similarity_threshold:
            matching_sensors = int(best_similarity * 10)
            self.logger.info(f"Match found: User {best_match_id} with {matching_sensors}/10 sensors matching")
            return best_match_id, best_similarity
        else:
            matching_sensors = int(best_similarity * 10)
            self.logger.info(f"No match found. Best was {matching_sensors}/10 sensors matching")
            return None, best_similarity
    
    def add_new_user(self, offset_profile):

        if len(self.profiles) >= self.max_users:
            self.logger.warning(f"Maximum number of users ({self.max_users}) reached. Cannot add new user.")
            return None
        
        # Generate new user ID
        user_id = len(self.profiles) + 1
        
        # Create new profile
        new_profile = {
            'user_id': user_id,
            'offset_profile': offset_profile,
            'created_at': datetime.now().isoformat()
        }
        
        self.profiles.append(new_profile)
        self._save_profiles()
        
        self.logger.info(f"Added new user: User {user_id}")
        return user_id
    
    def delete_user(self, user_id):

        for i, profile in enumerate(self.profiles):
            if profile['user_id'] == user_id:
                deleted_profile = self.profiles.pop(i)
                self._save_profiles()
                self.logger.info(f"Deleted User {user_id}")
                return True
        
        self.logger.warning(f"User {user_id} not found for deletion")
        return False
    
    def delete_newest_user(self):

        if not self.profiles:
            return None
        
        # Find newest user by created_at (most recent)
        newest_profile = max(self.profiles, key=lambda p: p.get('created_at', ''))
        user_id = newest_profile['user_id']
        
        self.delete_user(user_id)
        self.logger.info(f"Deleted newest user: User {user_id}")
        return user_id
    
    def get_all_users(self):
        return self.profiles
    
    def get_user_count(self):
        return len(self.profiles)
    
    def clear_all_users(self):
        self.profiles = []
        self._save_profiles()
        self.logger.info("Cleared all user profiles")