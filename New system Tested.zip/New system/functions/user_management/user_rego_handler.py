import time
import logging
import threading

from functions.user_management.user_profile_manager import UserProfileManager







class UserRegoHandler:
    SNAPSHOT_DURATION = 3  # seconds
    MODE_RECORD = "record"
    MODE_RECOGNITION = "recognition"
    
    def __init__(self, max_users=3, similarity_threshold=0.8, tolerance_percentage=4, mode="recognition", protocol=None, pub_topics=None):
        self.logger = logging.getLogger(f'{__name__}_{__class__.__name__}')
        self.max_users = max_users
        self.similarity_threshold = similarity_threshold  # e.g., 0.8 = 8 out of 10 sensors must match
        self.tolerance_percentage = tolerance_percentage  # e.g., 4 = 4% tolerance
        self.mode = mode  # "record" or "recognition"
        self.protocol = protocol
        self.pub_topics = pub_topics or {}
        
        # Initialize user profile manager
        self.profile_manager = UserProfileManager(
            max_users=self.max_users,
            similarity_threshold=self.similarity_threshold,
            tolerance_percentage=self.tolerance_percentage
        )
        
        # Snapshot variables
        self.offset_snapshots = []
        self.snapshot_start_time = None
        self.is_taking_snapshot = False
        self.snapshot_lock = threading.Lock()
        
        # Auto-trigger variables
        self.snapshot_triggered = False
        self.recognition_failed = False  # Track if recognition failed to enable retry
        self.zero_published = False  # Track if 0 has been published for this session
        
        self.logger.info(f"UserRegoHandler initialized in {self.mode.upper()} mode")
    
        
    def handle_user_rego(self, ods, aio_data):
        """
        Main handler that automatically starts snapshot when ODS becomes 1
        Retries recognition until successful, or switches to record mode if commanded.
    
        Args:
            ods: Occupant detection status (0 or 1)
            aio_data: Dictionary containing offset data
        """
        # When ODS goes to 0, reset everything
        if ods == 0:
            if self.snapshot_triggered or self.is_taking_snapshot or self.recognition_failed:
                self.logger.info("ODS = 0: Resetting user recognition session")
                self._reset_snapshot()
            self.snapshot_triggered = False
            self.recognition_failed = False
            self.zero_published = False  # Reset zero published flag
            return
    
        # Auto-trigger snapshot when receiving ODS = 1 (only once per session)
        if ods == 1 and not self.snapshot_triggered and not self.recognition_failed:
            self._start_snapshot()
            self.snapshot_triggered = True
    
        # Retry snapshot if recognition previously failed (keep retrying)
        if ods == 1 and self.recognition_failed and not self.is_taking_snapshot:
            self._start_snapshot()
    
        # Handle ongoing snapshot (only when ODS = 1)
        if ods == 1 and self.is_taking_snapshot:
            self._collect_snapshot_data(aio_data)



    def _start_snapshot(self):
        """Start taking offset snapshots for 3 seconds"""
        with self.snapshot_lock:
            if self.is_taking_snapshot:
                self.logger.warning("Snapshot already in progress")
                return
            
            self.is_taking_snapshot = True
            self.offset_snapshots = []
            self.snapshot_start_time = time.time()
            self.logger.info("="*60)
            self.logger.info("Started user recognition snapshot (3 seconds)")
            self.logger.info("="*60)
    
    def _collect_snapshot_data(self, aio_data):
        """
        Collect offset data during the snapshot period
        
        Args:
            aio_data: Dictionary containing offset data
        """
        if not self.is_taking_snapshot:
            return
        
        current_time = time.time()
        elapsed_time = current_time - self.snapshot_start_time
        
        # Check if snapshot duration has elapsed
        if elapsed_time >= self.SNAPSHOT_DURATION:
            self._finalize_snapshot()
            return
        
        # Collect offset data - filter to valid sensors only
        if aio_data and 'offset' in aio_data:
            filtered_offset = self.profile_manager._filter_offset_data(aio_data['offset'])
            offset_data = {
                'timestamp': elapsed_time,
                'offset': filtered_offset
            }
            self.offset_snapshots.append(offset_data)
    
    def _finalize_snapshot(self):
        """Finalize the snapshot and identify/register the user"""
        with self.snapshot_lock:
            if not self.is_taking_snapshot:
                return
            
            self.is_taking_snapshot = False
            
            if not self.offset_snapshots:
                self.logger.warning("No offset data collected during snapshot")
                return
            
            # Calculate average offset profile
            avg_offset = self.profile_manager.calculate_average_offset(self.offset_snapshots)
            
            self.logger.info("="*60)
            self.logger.info("USER RECOGNITION ATTEMPT")
            self.logger.info(f"Samples collected: {len(self.offset_snapshots)}")
            self.logger.info(f"Average offset profile: {avg_offset}")
            self.logger.info("="*60)
            
            # Try to match with existing user
            user_id, similarity = self.profile_manager.find_matching_user(avg_offset)
            
            if user_id is not None:
                # Existing user recognized - success!
                matching_sensors = int(similarity * 10)
                self.logger.info(f"✓ RECOGNIZED: User {user_id} ({matching_sensors}/10 sensors matching)")
                self.recognition_failed = False  # Reset retry flag on success
                self.zero_published = False  # Reset zero flag on success
                # Publish user ID
                if self.protocol and self.pub_topics.get("user_recognition_pub"):
                    self.protocol.send(self.pub_topics.get("user_recognition_pub"), user_id, 2, False)
                    self.logger.info(f"Published user_id: {user_id}")
            else:
                # No match found - enter retry mode or record mode
                matching_sensors = int(similarity * 10)
                self.logger.info(f"✗ NO MATCH FOUND ({matching_sensors}/10 sensors matching with best profile)")
                
                if self.mode == self.MODE_RECORD:
                    # In RECORD mode: Save new user or publish 0
                    current_user_count = self.profile_manager.get_user_count()
                    max_users = self.profile_manager.max_users
                    
                    if current_user_count >= max_users:
                        self.logger.warning(f"✗ NEW USER detected but maximum users ({max_users}) reached!")
                        self.logger.info("Consider deleting an old user to register this new user")
                        # Publish 0 for unrecognized user (only if not already published)
                        if not self.zero_published and self.protocol and self.pub_topics.get("user_recognition_pub"):
                            self.protocol.send(self.pub_topics.get("user_recognition_pub"), 0, 2, False)
                            self.logger.info("Published user_id: 0 (max users reached)")
                            self.zero_published = True
                        self.recognition_failed = False
                    else:
                        # Add new user
                        new_user_id = self.profile_manager.add_new_user(avg_offset)
                        self.logger.info(f"✓ NEW USER registered: User {new_user_id}")
                        self.logger.info(f"Total users: {current_user_count + 1}/{max_users}")
                        self.zero_published = False
                        # Publish new user ID
                        if self.protocol and self.pub_topics.get("user_recognition_pub"):
                            self.protocol.send(self.pub_topics.get("user_recognition_pub"), new_user_id, 2, False)
                            self.logger.info(f"Published user_id: {new_user_id}")
                        self.recognition_failed = False
                else:
                    # In RECOGNITION mode: Publish 0 and enter retry mode (only if not already published)
                    self.logger.info(f"Mode is {self.mode.upper()} - Entering retry mode. Waiting for match or record command...")
                    if not self.zero_published and self.protocol and self.pub_topics.get("user_recognition_pub"):
                        self.protocol.send(self.pub_topics.get("user_recognition_pub"), 0, 2, False)
                        self.logger.info("Published user_id: 0 (unknown user)")
                        self.zero_published = True
                    self.recognition_failed = True  # Enable retry
            
            self.logger.info("="*60)
    
    def _reset_snapshot(self):
        """Reset snapshot state when user leaves"""
        with self.snapshot_lock:
            self.offset_snapshots = []
            self.snapshot_start_time = None
            self.is_taking_snapshot = False
            self.logger.info("Snapshot state reset")
    
    def set_mode(self, mode):
        """
        Change the operating mode
        
        Args:
            mode: Either "record" or "recognition"
        """
        if mode in [self.MODE_RECORD, self.MODE_RECOGNITION]:
            self.mode = mode
            # If switching to RECORD, reset retry flag to stop retrying
            if mode == self.MODE_RECORD:
                self.recognition_failed = False
                self.snapshot_triggered = False  # Reset to allow immediate recording
            self.logger.info(f"Mode changed to: {self.mode.upper()}")
        else:
            self.logger.error(f"Invalid mode: {mode}. Use 'record' or 'recognition'")
    
    def get_mode(self):
        """Get current o
        perating mode"""
        return self.mode
    
    def delete_user(self, user_id):
        """
        Delete a user profile
        
        Args:
            user_id: ID of the user to delete
        """
        success = self.profile_manager.delete_user(user_id)
        if success:
            self.logger.info(f"User {user_id} deleted successfully")
        return success
    
    def delete_oldest_user(self):
        """Delete the newest user to make room for a new one"""
        deleted_id = self.profile_manager.delete_newest_user()
        if deleted_id:
            self.logger.info(f"Newest user (User {deleted_id}) deleted successfully")
        return deleted_id
    
    def get_all_users(self):
        """Get all registered users"""
        return self.profile_manager.get_all_users()
    
    def clear_all_users(self):
        """Clear all registered users"""
        self.profile_manager.clear_all_users()
        self.logger.info("All users cleared")
    
    def reset(self):
        """Reset the handler state"""
        with self.snapshot_lock:
            self.offset_snapshots = []
            self.snapshot_start_time = None
            self.is_taking_snapshot = False
            self.snapshot_triggered = False
            self.recognition_failed = False
            self.zero_published = False
            self.logger.info("UserRegoHandler reset")


