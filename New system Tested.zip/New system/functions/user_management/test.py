#!/usr/bin/env python3
"""
MQTT test script for user management service

Test cases:
    1. Set record mode
    2. Request user count
    3. Clear newest user
    4. Reset service
"""

import paho.mqtt.client as mqtt
import sys
import time
import threading

# MQTT Configuration
MQTT_BROKER = "127.0.0.1"  # Change to your broker address
MQTT_PORT = 1883

# MQTT Topics
TOPICS = {
    "record_mode": "SM/UserRecognition/Start/Recording",
    "users_request": "HMI/SM/UsersRequest",
    "clear_user": "HMI/SM/Clear",
    "reset": "SM/Seat/Reset"
}

# Listen topics
LISTEN_TOPICS = [
    "UserRecognition/SM/UserId",
    "HMI/SM/Users",
]

client = None
listening = False

def on_connect(client, userdata, flags, rc):
    """Callback for when the client connects to the broker"""
    if rc == 0:
        print("✓ Connected to MQTT broker")
        # Subscribe to listen topics
        for topic in LISTEN_TOPICS:
            client.subscribe(topic)
            print(f"  Subscribed to: {topic}")
    else:
        print(f"✗ Failed to connect, return code {rc}")

def on_message(client, userdata, msg):
    """Callback for when a message is received"""
    print(f"\n📨 Message received on topic: {msg.topic}")
    print(f"   Payload: {msg.payload.decode()}")
    print()

def start_listener():
    """Start MQTT listener in background"""
    global client, listening
    
    client = mqtt.Client()
    client.on_connect = on_connect
    client.on_message = on_message
    
    try:
        print("Starting MQTT listener...")
        client.connect(MQTT_BROKER, MQTT_PORT, 60)
        client.loop_start()
        listening = True
        time.sleep(1)  # Give time to connect and subscribe
    except Exception as e:
        print(f"✗ Error starting listener: {e}")
        listening = False

def stop_listener():
    """Stop MQTT listener"""
    global client, listening
    if listening and client:
        client.loop_stop()
        client.disconnect()
        listening = False
        print("\nMQTT listener stopped")

def send_mqtt_message(topic, payload):
    """
    Send MQTT message to specified topic
    
    Args:
        topic: MQTT topic name
        payload: Message payload
    """
    pub_client = mqtt.Client()
    
    try:
        print(f"Connecting to MQTT broker at {MQTT_BROKER}:{MQTT_PORT}...")
        pub_client.connect(MQTT_BROKER, MQTT_PORT, 60)
        
        pub_client.loop_start()
        time.sleep(0.5)
        
        print(f"Publishing to topic '{topic}' with payload: {payload}")
        result = pub_client.publish(topic, str(payload), qos=2, retain=False)
        
        time.sleep(1)
        
        if result.rc == mqtt.MQTT_ERR_SUCCESS:
            print(f"✓ Successfully published to {topic}")
        else:
            print(f"✗ Failed to publish. Error code: {result.rc}")
        
    except Exception as e:
        print(f"✗ Error: {e}")
    finally:
        pub_client.loop_stop()
        pub_client.disconnect()

def test_record_mode():
    """Test: Set user recognition to RECORD mode"""
    print("\n" + "="*60)
    print("TEST 1: Set Record Mode")
    print("="*60)
    send_mqtt_message(TOPICS["record_mode"], "1")

def test_users_request():
    """Test: Request current user count"""
    print("\n" + "="*60)
    print("TEST 2: Request User Count")
    print("="*60)
    send_mqtt_message(TOPICS["users_request"], "1")

def test_clear_user():
    """Test: Clear the newest user"""
    print("\n" + "="*60)
    print("TEST 3: Clear Newest User")
    print("="*60)
    send_mqtt_message(TOPICS["clear_user"], "1")

def test_reset():
    """Test: Reset the entire service"""
    print("\n" + "="*60)
    print("TEST 4: Reset Service")
    print("="*60)
    send_mqtt_message(TOPICS["reset"], "1")

def run_all_tests():
    """Run all test cases sequentially"""
    print("\n" + "="*60)
    print("USER MANAGEMENT SERVICE TEST SUITE")
    print("="*60)
    
    test_record_mode()
    time.sleep(2)
    
    test_users_request()
    time.sleep(2)
    
    test_clear_user()
    time.sleep(2)
    
    test_reset()
    
    print("\n" + "="*60)
    print("ALL TESTS COMPLETED")
    print("="*60)

def main():
    if len(sys.argv) < 2:
        print("Usage: python test.py <test_case>")
        print("\nAvailable test cases:")
        print("  record         - Set record mode")
        print("  request        - Request user count")
        print("  clear          - Clear newest user")
        print("  reset          - Reset service")
        print("  all            - Run all tests")
        print("  listen         - Listen to response topics only")
        sys.exit(1)
    
    test_case = sys.argv[1].lower()
    
    # Start listener before running tests
    start_listener()
    
    try:
        if test_case == "record":
            test_record_mode()
        elif test_case == "request":
            test_users_request()
        elif test_case == "clear":
            test_clear_user()
        elif test_case == "reset":
            test_reset()
        elif test_case == "all":
            run_all_tests()
        elif test_case == "listen":
            print("Listening to topics. Press Ctrl+C to stop...")
            while True:
                time.sleep(1)
        else:
            print(f"Error: Unknown test case '{test_case}'")
            sys.exit(1)
        
        # Wait a bit for responses
        if test_case != "listen":
            time.sleep(2)
    
    except KeyboardInterrupt:
        print("\n\nInterrupted by user")
    finally:
        stop_listener()

if __name__ == "__main__":
    main()