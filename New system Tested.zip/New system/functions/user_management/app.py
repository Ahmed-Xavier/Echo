import os
import logging
import json
import socket
import time
import threading

from functions.user_management.user_rego_handler import UserRegoHandler
from network.protocol_factory import ProtocolFactory
import joblib

class UserManagement:

    def __init__(self, config, protocol=None):
        os.chdir(os.path.abspath(os.path.dirname(__file__)))
        super().__init__()
        self.logger = logging.getLogger(f'{__name__}_{__class__.__name__}')
        self.config = config
        self.protocol = protocol
        # MQTT Config
        self.sub_topics = self.config.get('protocol').get('sub_topics')
        self.pub_topics = self.config.get('protocol').get('pub_topics')
        self.protocol.subscribe()
        print("Subscribed to topics:", self.sub_topics)
        self.protocol.set_on_receive_callback(self.mqtt_on_message)
        print("MQTT protocol initialized and callbacks set.")
        
        self.ods = 0
        self.user_management_active = False  # Flag to control when user management runs
        
        # Setup protocols
        
        self.aio_protocol = ProtocolFactory.create_instance(config.get('aio_protocol'))
        self.aio_protocol.set_on_receive_callback(self.on_aio_receive)


        self.aio_data = {'offset': [0] * 10}
     

        self.user_rego_handler = UserRegoHandler(
            max_users=3,
            similarity_threshold=0.6,
            tolerance_percentage=11,
            protocol=self.protocol,
            pub_topics=self.pub_topics
        )


        self.thread = threading.Thread(target=self.handle_user_management)
        self.stop_recv_event = threading.Event()
        self.thread.start()

        # Initialize all states
        
        self.reset()

    def mqtt_on_message(self, message):

        if message.topic == self.sub_topics["reset_sub"]:
            try:
                self.logger.info("Reset signal received on reset_sub topic")
                self.reset()
            except Exception as e:
                self.logger.error(f"Error handling reset: {e}")
        
        elif message.topic == self.sub_topics["user_record_start_sub"]:
            try:
                payload_value = int(message.payload.decode())
                if payload_value == 1:
                    self.user_rego_handler.set_mode("record")
                    self.logger.info("User recognition mode set to: RECORD")
                    self.user_management_active = True
                    # Reset snapshot trigger to allow immediate recording on next ODS=1
                    if self.ods == 1:
                        self.user_rego_handler.snapshot_triggered = False
                else:
                    self.logger.debug(f"Ignored user_record_start_sub with value: {payload_value}")
            except Exception as e:
                self.logger.error(f"Error setting record mode: {e}")
                
        elif message.topic == self.sub_topics.get("users_request_sub"):
            try:
                payload_value = message.payload.decode()
                if payload_value == "1":
                    self.logger.info("User request received - activating user management")
                    self.user_management_active = True
                    self.user_rego_handler.set_mode("recognition")
                
                    # IMPORTANT: Reset snapshot_triggered to allow new snapshot if user is already seated
                    if self.ods == 1:
                        self.user_rego_handler.snapshot_triggered = False
                        self.user_rego_handler.recognition_failed = False
                        self.user_rego_handler.zero_published = False
                        self.logger.info("User already seated - reset snapshot flags for new recognition")
                
                    self._send_users_count()
            except Exception as e:
                self.logger.error(f"Error handling users request: {e}")

        
        elif message.topic == self.sub_topics.get("clear_user_sub"):
            try:
                payload_value = message.payload.decode()
                if payload_value == "1":
                    self._clear_last_user()
            except Exception as e:
                self.logger.error(f"Error clearing user: {e}")

    ####################################################################################################################
    def on_aio_receive(self, data):
            try:
               # print(f"aio_data  connected")
               
                self.aio_data = json.loads(data)
            except Exception as e:
                print(f"Error parsing AIO data: {data}, error: {e}")
            self.ods = 1 if int(self.aio_data.get('object_human')) == 2 else 0

    def on_exit(self):
        self.protocol.disconnect()
        self.aio_protocol.disconnect()
        self.stop_recv_event.set()
        self.thread.join(timeout=2)



####################################################################################################################




    def handle_user_management(self) :
        while not self.stop_recv_event.is_set():
                try:
                    # Only handle user recognition if user management is active
                    if self.user_management_active:
                        self.user_rego_handler.handle_user_rego(self.ods, self.aio_data)
                        # Deactivate after user leaves (ODS = 0)
                        if self.ods == 0:
                            self.user_management_active = False
                
                    time.sleep(0.01)
                except Exception as e:
                    self.logger.error(f"Error in  loop: {str(e)}")
                    time.sleep(0.1)

    def reset(self):
        self.logger.info("setting service user management to default...")
        self.user_management_active = False
        self.user_rego_handler.reset()

    def _send_users_count(self):
        """Send the current number of registered users"""
        user_count = self.user_rego_handler.profile_manager.get_user_count()
        self.protocol.send(self.pub_topics.get("users_response_pub"), str(user_count), 2, False)
        self.logger.info(f"Sent users count: {user_count}")

    def _clear_last_user(self):
        """Delete the oldest/last user from profiles"""
        deleted_user_id = self.user_rego_handler.delete_oldest_user()
        if deleted_user_id:
            self.logger.info(f"Cleared user {deleted_user_id}")
        else:
            self.logger.info("No users to clear")

