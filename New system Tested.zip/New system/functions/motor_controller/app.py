import os
import logging
from typing import Dict, Any
import threading


class MotorController:
    def __init__(self, config: Dict[str, Any], protocol=None):
        os.chdir(os.path.abspath(os.path.dirname(__file__)))
        self.logger = logging.getLogger(f'{__name__}_{__class__.__name__}')
        self.config = config
        self.protocol = protocol

        self.sub_topics = self.config.get('protocol').get('sub_topics')
        self.pub_topics = self.config.get('protocol').get('pub_topics')
        self.positions = self.config.get('positions', {})
        self.motors = self.config.get('motors', [])

        self.current_position = None
        self.reached_motors = set()
        self.expected_motors = set()
        self.target_positions = {}

        # Cache for retained motor positions
        self.last_motor_positions: Dict[str, float] = {}

        self.reached_topics = {
            self.sub_topics['track_reached_sub']: 'Track',
            self.sub_topics['backrest_reached_sub']: 'Backrest',
            self.sub_topics['tilt_reached_sub']: 'Tilt',
            self.sub_topics['height_reached_sub']: 'Height',
            self.sub_topics['cla_reached_sub']: 'CLA',
        }

        if self.protocol:
            self.protocol.on_receive = self.mqtt_on_message
            self.protocol.subscribe()
        self.position_timeout_s = 10
        self.position_tolerance = 2.0
        self.timeout_timer = None

        self.logger.info("MotorController initialized")

    # ---------------------------------------------------------

    def mqtt_on_message(self, message):
        topic = message.topic
        payload = message.payload.decode('utf-8')
        self.logger.info(f"Received message on topic {topic}: {payload}")

        # Position requests
        if topic == self.sub_topics.get('welcome_position_request_motors_sub'):
            self.move_to_position('welcome')
            return

        if topic == self.sub_topics.get('sport_position_request_motors_sub'):
            self.move_to_position('sport')
            return

        if topic == self.sub_topics.get('comfort_position_request_motors_sub'):
            self.move_to_position('comfort')
            return

        if topic == self.sub_topics.get('zerog_position_request_motors_sub'):
            self.move_to_position('zerog')
            return

        if topic == self.sub_topics.get('exit_position_request_motors_sub'):
            self.move_to_position('exit')
            return
        # Motor reached topics (retained)
        if topic in self.reached_topics:
            motor = self.reached_topics[topic]

            try:
                current_value = float(payload)
            except ValueError:
                self.logger.warning(f"Invalid payload for {motor}: {payload}")
                return

            # Always cache retained position
            self.last_motor_positions[motor] = current_value

            if not self.current_position:
                return

            if motor not in self.expected_motors:
                return

            target = self.target_positions.get(motor)
            tolerance = self.position_tolerance

            if abs(current_value - target) <= tolerance:
                if motor not in self.reached_motors:
                    self.logger.info(
                        f"{motor} reached target {target} (current={current_value})"
                    )

                self.reached_motors.add(motor)

                if self.reached_motors == self.expected_motors:
                    if self.timeout_timer:
                        self.timeout_timer.cancel()
                        self.timeout_timer = None

                    self.publish_position_reached(self.current_position)
                    self._reset_state()

    # ---------------------------------------------------------

    def move_to_position(self, position_name):
        if position_name not in self.positions:
            self.logger.error(f"Position {position_name} not defined")
            return

        if self.timeout_timer:
            self.timeout_timer.cancel()
            self.timeout_timer = None

        pos = self.positions[position_name]
        expected_motors = set(pos.keys())

        # Check retained positions → already at target
        already_reached = True
        for motor, target in pos.items():
            current = self.last_motor_positions.get(motor)
            if current is None or abs(current - target) > self.position_tolerance:
                already_reached = False
                break

        if already_reached:
            self.logger.info(
                f"Seat already at {position_name} position (retained values)"
            )
            self.publish_position_reached(position_name)
            return

        # Normal movement flow
        self.current_position = position_name
        self.reached_motors = set()
        self.expected_motors = expected_motors
        self.target_positions = pos.copy()

        self.timeout_timer = threading.Timer(
            self.position_timeout_s,
            self._on_position_timeout
        )
        self.timeout_timer.start()

        for motor, value in pos.items():
            pub_topic = self.pub_topics.get(f'set_{motor.lower()}_position_pub')
            if pub_topic:
                self.protocol.send(pub_topic, str(value), 2, False)
                self.logger.info(f"Published {value} to {pub_topic}")
            else:
                self.logger.error(f"No pub topic for motor {motor}")

    # ---------------------------------------------------------

    def _on_position_timeout(self):
        if not self.current_position:
            return

        missing = self.expected_motors - self.reached_motors
        missing_str = ", ".join(sorted(missing))

        self.logger.error(
            f"Motor timeout: {self.current_position} position not reached "
            f"(missing: {missing_str})"
        )

        # Still publish reached to unblock system
        self.publish_position_reached(self.current_position)
        self._reset_state()

    # ---------------------------------------------------------

    def publish_position_reached(self, position_name):
        pub_topic = self.pub_topics.get('position_reached_pub')
        if pub_topic:
            self.protocol.send(pub_topic, position_name, 2, False)
            self.logger.info(f"{position_name} position reached")
        else:
            self.logger.error(f"No pub topic for reached {position_name}")

    # ---------------------------------------------------------

    def _reset_state(self):
        self.current_position = None
        self.reached_motors = set()
        self.expected_motors = set()
        self.target_positions = {}
        self.timeout_timer = None

    # ---------------------------------------------------------

    def disconnect(self):
        if self.protocol:
            self.protocol.disconnect()
            self.logger.info("Disconnected from protocol")
